import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
/**
 * Represents the item list in the library system.
 * This class stores details about an item such as book,magazine and dvd.
 */
public class Items {
    /**
     * @param fileName the file of the items.
     * @return list of items.
     */
    private List<List<String>> readItemsTxt(String fileName) {
        List<List<String>> allLines = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                allLines.add(Arrays.asList(parts));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return allLines;
    }
    /**
     * @param fileName the file of items.
     * @return item list.
     */
    public List<List<String>> getReadItemsTxt(String fileName) {
        return readItemsTxt(fileName);
    }
    /**
     * @param fileName the file of items.
     * @return organized list of items.
     */
    private List<List<List<String>>> items(String fileName) {
        List<List<String>> books = new ArrayList<>();
        List<List<String>> magazines = new ArrayList<>();
        List<List<String>> dvd = new ArrayList<>();
        for (List<String> row : getReadItemsTxt(fileName)) {
            if (row.get(0).startsWith("B")) {books.add(row);}
            if (row.get(0).startsWith("M")) {magazines.add(row);}
            if (row.get(0).startsWith("D")) {dvd.add(row);}
        }
        List<List<List<String>>> allItems = new ArrayList<>();
        allItems.add(books);
        allItems.add(magazines);
        allItems.add(dvd);
        return allItems;
    }
    /**
     * get the organized list of items.
     * @param fileName the file of items.
     * @return organized list of items.
     */
    public List<List<List<String>>> getItems(String fileName){
        return items(fileName);
    }
    /**
     * @param id the id of the item.
     * @param fileName the file of items.
     * @return the row if the id of the item is in the row.
     */
    public List<String> findItem(String id,String fileName){
        for (List<String> row : getReadItemsTxt(fileName)) {
            if (row.get(1).equals(id))
                return row;
        }return null;
    }
    /**
     * get the book list.
     * @param fileName the file of items.
     * @return book list.
     */
    public List<List<String>> getBooks(String fileName){
        return getItems(fileName).get(0);
    }
    /**
     * get the magazine list.
     * @param fileName the file of items.
     * @return magazine list.
     */
    public List<List<String>> getMagazines(String fileName){
        return getItems(fileName).get(1);
    }
    /**
     * get the dvd list.
     * @param fileName the file of items.
     * @return dvd list.
     */
    public List<List<String>> getDVD(String fileName){
        return getItems(fileName).get(2);
    }
}
