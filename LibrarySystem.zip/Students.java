import java.util.List;
/**
 * Represents the student's information in the library system.
 * This class stores details about a student such as phone,name,department,faculty and grade.
 */
public class Students extends Users{
    private String phone;
    private String faculty;
    private String department;
    private String grade;
    private String name;
    /**
     * @param id the id of the student.
     * @param fileName the file of users.
     */
    public Students(String id, String fileName){
        for(List<String> row :getStudents(fileName)) {
            if (row.get(2).equals(id)){
                this.phone=row.get(3);
                this.faculty=row.get(5);
                this.name=row.get(1);
                this.department=row.get(4);
                this.grade=row.get(row.size()-1).concat("th");}}
    }
    /**
     * @param id the id of the student.
     * @param fileName the file of users.
     * @return the row if the id of the student is in the row.
     */
    private List<String>studentId(String id,String fileName) {
       for(List<String> row :getStudents(fileName)) {
           if (row.get(2).equals(id)){return row;}
       }return null;}
    /**
     * Gets the information of the student.
     * @return The student's information.
     */
    public List<String> getStudentId(String id, String fileName){
        return studentId(id, fileName);}
    /**
     * @param borrowNumber the number of the borrowing.
     * @return penalty if the borrowing number equal five.
     */
    public boolean penalty(int borrowNumber,String itemId){
        return borrowNumber != 5;}
    /**
     * Gets the phone of the student.
     * @return The student's phone.
     */
    public String getPhone() {
        return phone;
    }
    /**
     * Gets the faculty of the student.
     * @return The student's faculty.
     */
    public String getFaculty() {
        return faculty;
    }
    /**
     * Gets the department of the student.
     * @return The student's department.
     */
    public String getDepartment() {
        return department;
    }
    /**
     * Gets the grade of the student.
     * @return The student's grade.
     */
    public String getGrade() {
        return grade;
    }
    /**
     * Gets the name of the student.
     * @return The student's name.
     */
    public String getName() {
        return name;
    }

}


