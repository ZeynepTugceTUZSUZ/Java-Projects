import java.util.List;
/**
 * Represents the DVDs information in the library system.
 * This class stores details about a dvd such as id,name, director,category, and runtime.
 */
public class DVD extends Items{
    private String id;
    private String name;
    private String director;
    private String category;
    private String runtime;
    /**
     *
     * @param id the id of the dvd.
     * @param fileName the file of items.
     */
    public DVD(String id, String fileName){
        for(List<String> row :getDVD(fileName)) {
            if (row.get(1).equals(id)){
                this.id=id;
                this.name=row.get(2);
                this.director=row.get(3);
                this.category=row.get(4);
                this.runtime=row.get(5);}
        }}
    /**
     *
     * @param id the id of the dvd.
     * @param fileName the file of items.
     * @return the row if the id of the dvd is in the row.
     */
    private List<String> dvdId(String id, String fileName) {
        for(List<String> row :getDVD(fileName)) {
            if (row.get(1).equals(id)){return row;}
        }return null;}
    /**
     * Gets the information of the dvd.
     *
     * @return The DVDs information.
     */
    public List<String> getDvdId(String id, String fileName) {
        return dvdId(id,fileName);
    }
    /**
     * Gets the id of the dvd.
     *
     * @return The DVDs id.
     */
    public String getId() {
        return id;
    }
    /**
     * Gets the name of the dvd.
     *
     * @return The DVDs name.
     */
    public String getName() {
        return name;
    }
    /**
     * Gets the director of the dvd.
     *
     * @return The DVDs director.
     */
    public String getDirector() {
        return director;
    }
    /**
     * Gets the category of the dvd.
     *
     * @return The DVDs category.
     */
    public String getCategory() {
        return category;
    }
    /**
     * Gets the runtime of the dvd.
     *
     * @return The DVDs runtime.
     */
    public String getRuntime() {
        return runtime;
    }
}
