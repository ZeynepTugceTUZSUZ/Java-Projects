import java.util.List;
/**
 * Represents the book's information in the library system.
 * This class stores details about a book such as id,name, author, and genre.
 */
public class Book extends Items{
    private String id;
    private String name;
    private String author;
    private String genre;

    /**
     *
     * @param id the id of the book.
     * @param fileName the file of items.
     */
    public Book(String id, String fileName){
        for(List<String> row :getBooks(fileName)) {
            if (row.get(1).equals(id)){
                this.id=id;
                this.name=row.get(2);
                this.author=row.get(3);
                this.genre=row.get(4);}
        }}

    /**
     *
     * @param id the id of the book.
     * @param fileName the file of items.
     * @return the row if the id of the book is in the row
     */
    private List<String> booksId(String id, String fileName) {
        for(List<String> row :getBooks(fileName)) {
            if (row.get(1).equals(id)){return row;}
        }return null;
    }
    /**
     * Gets the information of the book.
     * @return The book's information.
     */
    public List<String> getBooksId(String id, String fileName) {
        return booksId(id,fileName);
    }
    /**
     * Gets the id of the book.
     * @return The book's id.
     */
    public String getId() {
        return id;
    }
    /**
     * Gets the name of the book.
     * @return The book's name.
     */
    public String getName() {
        return name;
    }
    /**
     * Gets the author of the book.
     * @return The author's name.
     */
    public String getAuthor() {
        return author;
    }
    /**
     * Gets the genre of the book.
     * @return The genre of the book.
     */
    public String getGenre() {
        return genre;
    }
}
