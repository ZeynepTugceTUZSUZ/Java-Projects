import java.io.IOException;
public class Main {
    public static void main(String[] args) throws IOException {
    LibrarySystem l = new LibrarySystem();
    String itemFile = args[0];
    String userFile = args[1];
    String commandFile = args[2];
    String outputFile = args[3];
        l.command(commandFile, userFile, itemFile, outputFile);
        l.displayUsers(commandFile, userFile, outputFile);
        l.displayItems(commandFile,itemFile,outputFile);
    }
}