import java.util.List;
/**
 * Represents the academic member's information in the library system.
 * This class stores details about an academic member such as phone,name,department,faculty and title.
 */
public class AcademicStaff extends Users{
    private String name;
    private String phone;
    private String department;
    private String faculty;
    private String title;
    /**
     * @param id the id of the academic member.
     * @param fileName the file of users.
     */
    public AcademicStaff(String id,String fileName){
        for(List<String> row :getAcademicMembers(fileName)) {
            if (row.get(2).equals(id)){
        this.phone=row.get(3);
        this.faculty=row.get(5);
        this.name=row.get(1);
        this.title=row.get(6);
        this.department=row.get(4);}}
    }
    /**
     * @param id the id of the academic member.
     * @param fileName the file of users.
     * @return the row if the id of the academic member is in the row.
     */
    private List<String> academicId(String id, String fileName) {
        for(List<String> row :getAcademicMembers(fileName)) {
            if (row.get(2).equals(id)){return row;}
        }return null;}
    /**
     * Gets the information of the academic member.
     * @return The academic member's information.
     */
    public List<String> getAcademicId(String id, String fileName){
        return academicId(id, fileName);}
    /**
     * @param borrowNumber the number of the borrowing.
     * @return penalty if the borrowing number equal three.
     */
    public boolean penalty(int borrowNumber,String itemid){
        return (borrowNumber != 3);}
    /**
     * Gets the name of the academic member.
     * @return The academic member's name.
     */
    public String getName() {
        return name;
    }
    /**
     * Gets the phone of the academic member.
     * @return The academic member's phone.
     */
    public String getPhone() {
        return phone;
    }
    /**
     * Gets the department of the academic member.
     * @return The academic member's department.
     */
    public String getDepartment() {
        return department;
    }
    /**
     * Gets the faculty of the academic member.
     * @return The academic member's faculty.
     */
    public String getFaculty() {
        return faculty;
    }
    /**
     * Gets the title of the academic member.
     * @return The academic member's title.
     */
    public String getTitle() {
        return title;
    }

}
