import java.io.*;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
public class LibrarySystem {
    Items item =new Items();
    Users user =new Users();
    /**
     * @param input the command file
     * @return commands
     */
    private List<List<String>> commandTxt(String input){
        List<List<String>> allCommands = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(
                input))) {
            String line;
            while((line = br.readLine()) != null){
                String[] parts = line.split(",");
                allCommands.add(Arrays.asList(parts));}
        }catch (IOException e) {
            e.printStackTrace();}
        return allCommands;}
    /**
     * @param input the command file
     * @return commands
     */
    public List<List<String>> getCommandTxt(String input){
        return commandTxt(input);}

    private HashMap<String, Integer> borrowCounts;
    private HashMap<String, Integer> penaltyCounts;
    private List<List<String>> cannotBorrowItems;//includes borrowed items information.
    private List<List<String>> borrowedInfo;//includes username,item name and date borrowed.

    /**
     *
     * @throws FileNotFoundException
     */
    public LibrarySystem() throws FileNotFoundException {
        this.borrowCounts = new HashMap<>();
        this.penaltyCounts= new HashMap<>();
        this.cannotBorrowItems= new ArrayList<>();
        this.borrowedInfo=new ArrayList<>();
    }

    /**
     * @param userId the id of the user.
     * @return borrowing number,show the number of borrowings if there is a user,otherwise return 0.
     */
    public int getBorrowNumber(String userId) {
        return borrowCounts.getOrDefault(userId, 0);
    }
    /**
     * @param userId the id of the user.
     * @return penalty number,show the number of penalties if there is a user,otherwise return 0.
     */
    public int getPenaltyCount(String userId) {
        return penaltyCounts.getOrDefault(userId, 0);
    }
    /**
     * @param itemName the name of the item.
     * @return item information if the item name exists in the borrowed list.
     */
    public List<String> findBorrowedInfoByName(String itemName) {
        for (List<String> row : borrowedInfo) {
            if (row.contains(itemName)) {
                return row;
            }
        }return null;
    }
    /**
     * calculate the penalty.
     * @param userFile the file of the users.
     * @param itemFile the file of the items.
     * @param row the command line.
     */
    public void calcPenalty(String userFile, String itemFile, List<String> row){
        String prevDateString =row.get(3);// Date in the command line.
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        LocalDate prevDate = LocalDate.parse(prevDateString ,formatter);
        LocalDate currentDate =LocalDate.now();//Today's date.
        List<String> borrowInfo = new ArrayList<>();
        long daysBetween = ChronoUnit.DAYS.between(prevDate, currentDate) +1 ;
        String userId=row.get(1);
        String itemId=row.get(2);
        int currentCount = penaltyCounts.getOrDefault(userId, 0);
        /**
         *if the command is pay,set penalty to 0.
         */
        if (row.get(0).equalsIgnoreCase("pay")){
            penaltyCounts.put(row.get(1),0);}
        /**
         * if the command is borrow,check the time between two days and act accordingly.
         */
        if (row.get(0).equalsIgnoreCase("borrow")){
            if (borrow(userId,itemId,itemFile,userFile)){
                borrow(userId,itemId,itemFile,userFile);
            borrowInfo.add(user.findUser(userId,userFile).get(1));
            borrowInfo.add(item.findItem(itemId, itemFile).get(2));
            borrowInfo.add(row.get(row.size()-1));
            borrowedInfo.add(borrowInfo);}
            if (getPenaltyCount(userId)>=6){return;}//if penalty is 6 ,give warning.
            if (user.getAcademicMembers(userFile).contains(user.findUser(userId, userFile)) && daysBetween >= 15) {
                currentCount+=2;
                penaltyCounts.put(row.get(1), currentCount);
                borrowedInfo.remove(borrowInfo);
                cannotBorrowItems.remove(item.findItem(itemId, itemFile));
                borrowCounts.put(userId, getBorrowNumber(userId) - 1);
            } else if (user.getStudents(userFile).contains(user.findUser(userId, userFile)) && daysBetween >= 30) {
                currentCount+=2;
                penaltyCounts.put(row.get(1), currentCount);
                borrowedInfo.remove(borrowInfo);
                cannotBorrowItems.remove(item.findItem(itemId, itemFile));
                borrowCounts.put(userId, getBorrowNumber(userId) - 1);
            } else if (user.getGuests(userFile).contains(user.findUser(userId, userFile)) && daysBetween >= 7) {
                currentCount+=2;
                penaltyCounts.put(row.get(1), currentCount);
                borrowedInfo.remove(borrowInfo);
                cannotBorrowItems.remove(item.findItem(itemId, itemFile));
                borrowCounts.put(userId, getBorrowNumber(userId) - 1);}}
    }
    /**
     * @param userId the id of the user.
     * @param itemId the id of the item.
     * @param itemFile the file of the items.
     * @param userFile the file of the users.
     * @return true if it contains some properties.
     */
    public boolean borrow(String userId,String itemId,String itemFile,String userFile) {
        int currentCount = getBorrowNumber(userId);
        List<List<String>> items = item.getReadItemsTxt(itemFile);
        for (List<String> row: items) {
            if ((user.getStudents(userFile).contains(user.findUser(userId, userFile)) && !row.get(row.size()-1).equalsIgnoreCase("reference")) ||//students cannot borrow reference items.
                (user.getAcademicMembers(userFile).contains(user.findUser(userId, userFile))) ||
                (user.getGuests(userFile).contains(user.findUser(userId, userFile)) && (!row.get(row.size()-1).equalsIgnoreCase("rare") && !row.get(row.size()-1).equalsIgnoreCase("limited")))){//guests cannot borrow rare or limited items.
            if (row.get(1).equals(itemId) && !cannotBorrowItems.contains(row)) {//if the item has not been borrowed before,
                cannotBorrowItems.add(row);
                borrowCounts.put(userId, currentCount + 1);
                return true;
                }}}
        return false;
    }
    /**
     * @param userId the id of the user.
     * @param itemId the id of the item.
     * @param itemFile the file of the items.
     */
    public void returnCommand(String userId,String itemId,String itemFile){
        int currentCount = getBorrowNumber(userId);
        for (List<String> row: item.getReadItemsTxt(itemFile)){
            if (row.get(1).equals(itemId)){cannotBorrowItems.remove(row);//if the item id is equal to the itemId parameter,remove the item from the list.
                borrowCounts.put(userId, currentCount - 1);}//reduce the number of borrowings by 1.
            if (row.get(1).equals(itemId) && findBorrowedInfoByName(row.get(2))!=null){borrowedInfo.remove(findBorrowedInfoByName(row.get(2)));//if the borrowedInfo includes the item name,remove the item from the list.
            }}
    }
    /**
     * make the necessary checks and write the outputs.
     * @param commandFile the file of the commands.
     * @param userFile the file of the users.
     * @param itemFile the file of the items.
     * @param outputFile the file of the output.
     */
    public void command(String commandFile,String userFile,String itemFile,String outputFile) {try(
        PrintWriter writer = new PrintWriter(new FileWriter(outputFile))){
        List<List<String>> commands = getCommandTxt(commandFile);
        for (List<String> row : commands){
            if (row.get(0).equalsIgnoreCase("borrow")){
                String userId=row.get(1);
                String itemId=row.get(2);
                AcademicStaff academic =new AcademicStaff(userId,userFile);
                Students student = new Students(userId,userFile);
                Guest guests =new Guest(userId,userFile);
                if (academic.getAcademicId(row.get(1),userFile)!=null){if (getPenaltyCount(userId)<6) {if (academic.penalty(getBorrowNumber(row.get(1)),row.get(2))){if (!cannotBorrowItems.contains(item.findItem(itemId,itemFile))){calcPenalty(userFile,itemFile,row);
                    writer.println(user.findUser(userId,userFile).get(1) +" successfully borrowed! "+ item.findItem(itemId,itemFile ).get(2));}
                else writer.println(user.findUser(userId,userFile).get(1)+" cannot borrow "+item.findItem(itemId,itemFile ).get(2)+", it is not available!");}
                else writer.println(user.findUser(userId,userFile).get(1)+" cannot borrow "+item.findItem(itemId,itemFile ).get(2)+", since the borrow limit has been reached!");}
                else writer.println(user.findUser(userId,userFile).get(1) +" cannot borrow "+item.findItem(itemId,itemFile ).get(2)+", you must first pay the penalty amount! 6$");}

                else if (student.getStudentId(row.get(1),userFile)!=null){if (getPenaltyCount(userId)<6) {if (student.penalty(getBorrowNumber(row.get(1)),row.get(2))) {if (!cannotBorrowItems.contains(item.findItem(itemId,itemFile))){calcPenalty(userFile,itemFile,row);if (!item.findItem(row.get(2),itemFile).contains("reference")){
                    writer.println(user.findUser(userId,userFile).get(1) +" successfully borrowed! "+ item.findItem(itemId,itemFile ).get(2));}
                else writer.println(user.findUser(userId,userFile ).get(1)+" cannot borrow reference item!");}
                else writer.println(user.findUser(userId,userFile).get(1)+" cannot borrow "+item.findItem(itemId,itemFile ).get(2)+", it is not available!");}
                else writer.println(user.findUser(userId,userFile).get(1)+" cannot borrow "+item.findItem(itemId,itemFile ).get(2)+", since the borrow limit has been reached!");}
                else writer.println(user.findUser(userId,userFile).get(1) +" cannot borrow "+item.findItem(itemId,itemFile ).get(2)+", you must first pay the penalty amount! 6$");}

            else if (guests.getGuestId(row.get(1),userFile)!=null){if (getPenaltyCount(userId)<6){if (guests.penalty(getBorrowNumber(row.get(1)))){if (!cannotBorrowItems.contains(item.findItem(row.get(2),itemFile))){calcPenalty(userFile,itemFile,row);if (!item.findItem(itemId,itemFile).contains("rare") && !item.findItem(row.get(2),itemFile).contains("limited")){
                    writer.println(user.findUser(userId,userFile).get(1) +" successfully borrowed! "+ item.findItem(itemId,itemFile ).get(2));}
                else writer.println(user.findUser(userId,userFile ).get(1)+" cannot borrow " + item.findItem(itemId,itemFile).get(6) +" item!");}
                else writer.println(user.findUser(userId,userFile).get(1)+" cannot borrow "+item.findItem(itemId,itemFile ).get(2)+", it is not available!");}
                else writer.println(user.findUser(userId,userFile).get(1)+" cannot borrow "+item.findItem(itemId,itemFile ).get(2)+", since the borrow limit has been reached!");}
                else writer.println(user.findUser(userId,userFile).get(1) +" cannot borrow "+item.findItem(itemId,itemFile ).get(2)+", you must first pay the penalty amount! 6$");}}

                else if (row.get(0).equalsIgnoreCase("return")){
                String userId=row.get(1);
                String itemId=row.get(2);
                AcademicStaff academic =new AcademicStaff(userId,userFile);
                Students student = new Students(userId,userFile);
                Guest guests =new Guest(userId,userFile);
                if (academic.getAcademicId(userId,userFile)!=null){returnCommand(userId,itemId,itemFile);
                    writer.println(academic.getAcademicId(userId,userFile).get(1) +" successfully returned "+ item.findItem(itemId,itemFile ).get(2));}
                else if (student.getStudentId(userId,userFile)!=null){returnCommand(userId,itemId,itemFile);
                    writer.println(student.getStudentId(userId,userFile).get(1) +" successfully returned "+ item.findItem(itemId,itemFile ).get(2));}
                else if (guests.getGuestId(userId,userFile)!=null){returnCommand(userId,itemId,itemFile);
                    writer.println(guests.getGuestId(userId,userFile).get(1) +" successfully returned "+ item.findItem(itemId,itemFile ).get(2));}}
            else if (row.get(0).equalsIgnoreCase("pay")){
                penaltyCounts.put(row.get(1),0);
                writer.println(user.findUser(row.get(1),userFile ).get(1)+" has paid penalty");}}}
catch (IOException e) {
        e.printStackTrace();}}
    /**
     * @param commandFile the file of the commands.
     * @param userFile the file of the users.
     * @param outputFile the file of the outputs.
     */
    public void displayUsers(String commandFile,String userFile,String outputFile) {try(
        PrintWriter writer = new PrintWriter(new FileWriter(outputFile,true))){
        List<List<String>> commands = getCommandTxt(commandFile);
        List<List<String>> users = user.getReadUsersTxt(userFile);
        users.sort(Comparator.comparingInt(row -> Integer.parseInt(row.get(2))));
        writer.println();
        for (List<String> row : commands){
            if (row.get(0).equalsIgnoreCase("displayUsers")){
                for (List<String> userRow : users) {
                    writer.println();
                    String userId =userRow.get(2);
                    AcademicStaff academic =new AcademicStaff(userId,userFile);
                    Students student = new Students(userId,userFile);
                    Guest guests =new Guest(userId,userFile);
                    writer.println("------ User Information for " + userId +" ------");
                    if (academic.getAcademicId(userId,userFile)!=null){//if academic list includes user id ,write outputs.
                        writer.println("Name: " +academic.getTitle() + " " +academic.getName() + " Phone: " + academic.getPhone());
                        writer.println("Faculty: " + academic.getFaculty() + " Department: " + academic.getDepartment());}
                    else if (student.getStudentId(userId,userFile)!=null){//if student list includes user id ,write outputs.
                        writer.println("Name: " + student.getName() + " Phone: " + student.getPhone());
                        writer.println("Faculty: " + student.getFaculty() + " Department: " + student.getDepartment() +" Grade: " +student.getGrade());}
                    else if (guests.getGuestId(userId,userFile)!=null){//if guest list includes user id ,write outputs.
                        writer.println("Name: " + guests.getName() + " Phone: " + guests.getPhone());
                        writer.println("Occupation: " + guests.getOccupation());}}}}}
    catch (IOException e) {
        e.printStackTrace();}}
    /**
     * @param commandFile the file of the commands.
     * @param itemFile the file of the items.
     * @param outputFile the file of the outputs.
     */
    public void displayItems(String commandFile,String itemFile,String outputFile){try(
        PrintWriter writer = new PrintWriter(new FileWriter(outputFile,true))){
        List<List<String>> commands = getCommandTxt(commandFile);
        List<List<String>> items = item.getReadItemsTxt(itemFile);
        items.sort(Comparator.comparingInt(row -> Integer.parseInt(row.get(1))));
        writer.println();
        for (List<String> row : commands){
            if (row.get(0).equalsIgnoreCase("displayItems")){
                for (List<String> itemRow : items){
                    writer.println();
                    String itemId = itemRow.get(1);
                    Book books = new Book(itemId,itemFile);
                    Magazines magazine = new Magazines(itemId,itemFile);
                    DVD dvd = new DVD(itemId,itemFile);
                    writer.println("------ Item Information for " + itemId +" ------");
                    if (books.getBooksId(itemId,itemFile)!=null){//if book list includes user id ,write outputs.
                        writer.print("ID: " + books.getId() + " Name: " + books.getName());
                        boolean isBorrowed = false;
                        for (List<String> borrowedRow : borrowedInfo){//if borrowedInfo includes item name,write output.
                            if (borrowedRow.contains(itemRow.get(2))){
                                String userName= borrowedRow.get(0);
                                String borrowDate = borrowedRow.get(2);
                            writer.println(" Status: Borrowed" + " Borrowed Date: " + borrowDate + " Borrowed by: " + userName);
                            isBorrowed= true;}}
                        if (!isBorrowed){writer.println(" Status: Available");}
                        writer.println("Author: " + books.getAuthor() + " Genre: " + books.getGenre());}

                    else if (magazine.getMagazinesId(itemId,itemFile)!=null){//if magazine list includes user id ,write outputs.
                        writer.print("ID: " + magazine.getId() + " Name: " + magazine.getName());
                        boolean isBorrowed = false;
                        for (List<String> borrowedRow : borrowedInfo){//if borrowedInfo includes item name,write output.
                            if (borrowedRow.contains(itemRow.get(2))){
                                String userName= borrowedRow.get(0);
                                String borrowDate = borrowedRow.get(2);
                                writer.println(" Status: Borrowed" + " Borrowed Date: " + borrowDate + " Borrowed by: " + userName);
                                isBorrowed= true;}}
                        if (!isBorrowed){writer.println(" Status: Available");}
                        writer.println("Publisher: " + magazine.getPublisher() + " Category: " + magazine.getCategory());}

                    else if (dvd.getDvdId(itemId,itemFile)!=null){//if dvd list includes user id ,write outputs.
                        writer.print("ID: " + dvd.getId() + " Name: " + dvd.getName());
                        boolean isBorrowed = false;
                        for (List<String> borrowedRow : borrowedInfo){//if borrowedInfo includes item name,write output.
                            if (borrowedRow.contains(itemRow.get(2))){
                                String userName= borrowedRow.get(0);
                                String borrowDate = borrowedRow.get(2);
                                writer.println(" Status: Borrowed" + " Borrowed Date: " + borrowDate + " Borrowed by: " + userName);
                                isBorrowed= true;}}
                        if (!isBorrowed){writer.println(" Status: Available");}
                        writer.println("Director: " + dvd.getDirector() + " Category: " + dvd.getCategory() + " Runtime: " + dvd.getRuntime());}
                }}}}
    catch (IOException e) {
        e.printStackTrace();}}
}
