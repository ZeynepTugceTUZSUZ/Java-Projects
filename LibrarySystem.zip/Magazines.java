import java.util.List;
/**
 * Represents the magazine's information in the library system.
 * This class stores details about a magazine such as id,name, publisher, and category.
 */
public class Magazines extends Items {
    private String id;
    private String name;
    private String publisher;
    private String category;
    /**
     *
     * @param id the id of the magazine.
     * @param fileName the file of items.
     */
    public Magazines(String id, String fileName){
        for(List<String> row :getMagazines(fileName)) {
            if (row.get(1).equals(id)){
                this.id=id;
                this.name=row.get(2);
                this.publisher=row.get(3);
                this.category=row.get(4);}}
    }
    /**
     *
     * @param id the id of the magazine.
     * @param fileName the file of items.
     * @return the row if the id of the magazine is in the row.
     */
    private List<String> magazinesId(String id, String fileName) {
        for(List<String> row :getMagazines(fileName)) {
            if (row.get(1).equals(id)){return row;}
        }return null;}
    /**
     * Gets the information of the magazine.
     *
     * @return The magazine's information.
     */
    public List<String> getMagazinesId(String id, String fileName) {
        return magazinesId(id,fileName);
    }
    /**
     * Gets the id of the magazine.
     *
     * @return The magazine's id.
     */
    public String getId() {
        return id;
    }
    /**
     * Gets the name of the magazine.
     *
     * @return The magazine's name.
     */
    public String getName() {
        return name;
    }
    /**
     * Gets the publisher of the magazine.
     *
     * @return The magazine's publisher.
     */
    public String getPublisher() {
        return publisher;
    }
    /**
     * Gets the category of te magazine.
     *
     * @return The magazine's category.
     */
    public String getCategory() {
        return category;
    }

}
