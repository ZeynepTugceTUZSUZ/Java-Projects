import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;
/**
 * Represents the user list in the library system.
 * This class stores details about an item such as student,academic member and guest.
 */
public class Users {
    /**
     * @param fileName the file of the users.
     * @return list of users.
     */
    private List<List<String>> readUsersTxt(String fileName) {
        List<List<String>> allLines = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                allLines.add(new ArrayList<>(Arrays.asList(parts)));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return allLines;
    }
    /**
     * @param fileName the file of users.
     * @return user list.
     */
    public List<List<String>> getReadUsersTxt(String fileName) {
        return this.readUsersTxt(fileName);
    }
    /**
     * @param fileName the file of users.
     * @return organized list of users.
     */
    private List<List<List<String>>> members(String fileName) {
        List<List<String>> academicMembers = new ArrayList<>();
        List<List<String>> students = new ArrayList<>();
        List<List<String>> guests = new ArrayList<>();
        for (List<String> row : getReadUsersTxt(fileName)) {
            if (row.get(0).startsWith("A")) {academicMembers.add(row);}
                if (row.get(0).startsWith("S")) {students.add(row);}
                    if (row.get(0).startsWith("G")) {guests.add(row);}
            }
        List<List<List<String>>> allMembers = new ArrayList<>();
        allMembers.add(academicMembers);
        allMembers.add(students);
        allMembers.add(guests);
        return allMembers;
    }
    /**
     * get the organized list of users.
     * @param fileName the file of users.
     * @return organized list of users.
     */
    public List<List<List<String>>> getMembers(String fileName){
        return members(fileName);
    }
    /**
     * @param id the id of the user.
     * @param fileName the file of user.
     * @return the row if the id of the user is in the row.
     */
    public List<String> findUser(String id,String fileName){
        for (List<String> row : getReadUsersTxt(fileName)) {
            if (row.get(2).equals(id))
                return row;
        }return null;
    }
    /**
     * get the list of academic members.
     * @param fileName the file of the users.
     * @return the list of academic members.
     */
    public List<List<String>> getAcademicMembers(String fileName){
        return getMembers(fileName).get(0);
    }
    /**
     * get the list of students.
     * @param fileName the file of the users.
     * @return the list of students.
     */
    public List<List<String>> getStudents(String fileName){
        return getMembers(fileName).get(1);
    }
    /**
     * get the list of guests.
     * @param fileName the file of the users.
     * @return the list of guests.
     */
    public List<List<String>> getGuests(String fileName){
        return getMembers(fileName).get(2);
    }
}

