import java.util.List;
/**
 * Represents the guest's information in the library system.
 * This class stores details about a guest such as phone,name,occupation.
 */
public class Guest extends Users {
    private String phone;
    private String name;
    private String occupation;
    /**
     * @param id the id of the guest.
     * @param fileName the file of users.
     */
    public Guest(String id,String fileName){
        for (List<String> row : getGuests(fileName)) {
            if (row.get(2).equals(id)) {
                this.phone = row.get(3);
                this.name = row.get(1);
                this.occupation = row.get(row.size()-1);}}
    }
    /**
     * @param id the id of the guest.
     * @param fileName the file of users.
     * @return the row if the id of the guest is in the row.
     */
    private List<String> guestId(String id, String fileName) {
        for (List<String> row : getGuests(fileName)) {
            if (row.get(2).equals(id)) {
                return row;}
        }
        return null;
    }
    /**
     * Gets the information of the guest.
     * @return The guest's information.
     */
    public List<String> getGuestId(String id, String fileName) {
        return guestId(id, fileName);
    }

    /**
     * @param borrowNumber the number of the borrowing.
     * @return penalty if the borrowing number equal one.
     */
    public boolean penalty(int borrowNumber) {
        return borrowNumber != 1;
    }
    /**
     * Gets the phone of the guest.
     * @return The guest's phone.
     */
    public String getPhone() {
        return phone;
    }
    /**
     * Gets the name of the guest.
     * @return The guest's name.
     */
    public String getName() {
        return name;
    }
    /**
     * Gets the occupation of the guest.
     * @return The guest's occupation.
     */
    public String getOccupation() {
        return occupation;
    }
}