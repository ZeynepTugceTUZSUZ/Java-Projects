import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.scene.image.Image;
import javafx.scene.layout.Pane;
import javafx.util.Duration;
import javafx.scene.image.ImageView;
import java.util.List;
import java.util.Random;
/**
 * The {@code EnemyTank} class represents an enemy tank in the game.
 * It handles its autonomous movement, wall collision, wheel animation,
 * and image representation on the screen.
 */
public class EnemyTank implements Tank{
    /** Speed of the tank movement */
    private double speed = 15.0;
    /**
     * Represents the current direction of the tank.
     * Typically encoded as an integer where each value corresponds to a specific direction (e.g., 0 = up, 1 = right, etc.).
     */
    private int direction;

    /**
     * Random number generator used to determine random behaviors such as movement or shooting.
     */
    private Random random = new Random();

    /**
     * Timeline controlling the tank's automated movement and actions.
     * Used to schedule repeated tasks like moving or shooting at intervals.
     */
    private Timeline movementTimeline;

    /**
     * Reference to the main game controller to interact with the overall game state and logic.
     */
    private GameController gameController;
    /** ImageView that represents the tank's appearance on screen */
    private ImageView tankImage;

    /** First image used for tank animation */
    private Image image;

    /** Second image used for tank animation */
    private Image image1;

    /** Counter used for alternating between tank images for animation */
    private int number = 0;
    /**
     * Constructs a new enemy tank and places it on the game pane at the specified coordinates.
     * It initializes its images, sets a random direction, and starts automated movement.
     *
     * @param pane The game pane where the enemy tank will be displayed.
     * @param x Initial X coordinate.
     * @param y Initial Y coordinate.
     * @param walls List of walls for collision detection.
     * @param gameController Reference to the game controller.
     */
    public EnemyTank(Pane pane, double x, double y, List<ImageView> walls,GameController gameController) {
        this.gameController= gameController;
        image = new Image(getClass().getResource("/yellowTank1.png").toExternalForm());
        image1 = new Image(getClass().getResource("/yellowTank2.png").toExternalForm());
        tankImage = new ImageView(image);
        tankImage.setFitWidth(30);
        tankImage.setFitHeight(30);
        tankImage.setLayoutX(x);
        tankImage.setLayoutY(y);
        pane.getChildren().add(tankImage);
        direction = random.nextInt(4);
        startAutoMove(walls);
    }
    /**
     * Moves the tank in the specified direction unless a wall collision occurs.
     * If a collision happens, it reverts the move and changes direction randomly.
     *
     * @param dx Horizontal direction (-1, 0, or 1).
     * @param dy Vertical direction (-1, 0, or 1).
     * @param walls List of wall objects for collision detection.
     */
    public void move(int dx, int dy, List<ImageView> walls) {
        double nextX = tankImage.getLayoutX() + dx * speed;
        double nextY = tankImage.getLayoutY() + dy * speed;

        tankImage.setLayoutX(nextX);
        tankImage.setLayoutY(nextY);

        for (ImageView wall : walls) {
            if (tankImage.getBoundsInParent().intersects(wall.getBoundsInParent())) {

                tankImage.setLayoutX(tankImage.getLayoutX() - dx * speed);
                tankImage.setLayoutY(tankImage.getLayoutY() - dy * speed);

                direction = random.nextInt(4);
                return;
            }
        }
    }
    /**
     * Updates the tank's movement and rotation based on its current direction.
     * Also calls the method to animate the tank's wheels.
     *
     * @param walls List of wall objects for collision detection.
     */
    public void updateMove(List<ImageView> walls) {
        switch (direction) {
            case 0: move(0, -1, walls); tankImage.setRotate(270); break;
            case 1: move(0, 1, walls);  tankImage.setRotate(90); break;
            case 2: move(-1, 0, walls); tankImage.setRotate(180); break;
            case 3: move(1, 0, walls);  tankImage.setRotate(0); break;
        }animateWheels();
    }
    /**
     * Starts the timeline that controls automatic movement of the enemy tank.
     * The tank will periodically move in its current direction if the game is not over.
     *
     * @param walls  List of wall objects for collision detection.
     */
    public void startAutoMove(List<ImageView> walls) {
        movementTimeline = new Timeline(new KeyFrame(Duration.millis(250), e -> {
            if (!gameController.isGameOver()) {
                updateMove(walls);

            }
        }));
        movementTimeline.setCycleCount(Timeline.INDEFINITE);
        movementTimeline.play();
    }
    /**
     * Returns the {@code ImageView} representing the tank, used for collision checks and UI.
     *
     * @return The tank's {@code ImageView}.
     */
    public ImageView getTankImage() {
        return tankImage;
    }
    /**
     * Alternates between two images to simulate wheel animation.
     * This is called on every movement update.
     */
    public void animateWheels(){
        if (number%2==0){
            tankImage.setImage(image);
        }
        else {tankImage.setImage(image1);}
        number++;
    }
}
