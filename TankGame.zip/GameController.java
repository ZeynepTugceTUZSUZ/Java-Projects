import javafx.animation.AnimationTimer;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.Pane;
import java.util.*;
import javafx.scene.image.ImageView;
import javafx.util.Duration;
import javafx.scene.control.Label;
/**
 * Controls the core logic of the Tank Game including player movement, enemy spawning,
 * bullet shooting, collision detection, score/lives tracking, and game state management.
 */
public class GameController {

    /**
     * Root container pane for the entire game UI.
     */
    private Pane root;

    /**
     * The main scene where all the game elements are displayed.
     */
    private Scene scene;

    /**
     * The player's tank instance.
     */
    private PlayerTank player;

    /**
     * The game map containing walls, terrain, and other static elements.
     */
    private GameMap map;

    /**
     * List of enemy tank instances currently in the game.
     */
    private List<EnemyTank> enemies;

    /**
     * Maximum number of enemy tanks allowed in the game at the same time.
     */
    private static final int MAX_ENEMIES = 6;

    /**
     * Random number generator used for various random game events.
     */
    private Random random = new Random();

    /**
     * Timeline controlling the periodic firing of enemy tanks.
     */
    private Timeline enemyFireTimeline;

    /**
     * Label displaying the player's current score.
     */
    private Label scoreLabel;

    /**
     * Label displaying the player's remaining lives.
     */
    private Label livesLabel;

    /**
     * Label used to show the pause menu on the screen.
     */
    private Label pauseMenu;

    /**
     * The player's current score in the game.
     */
    private int score = 0;

    /**
     * Flag indicating whether the game is over.
     */
    public boolean isGameOver = false;

    /**
     * Set of currently pressed keyboard keys, used for handling continuous input.
     */
    private Set<KeyCode> pressedKeys = new HashSet<>();

    /**
     * Timestamp of the last time the player shot a bullet.
     */
    private long lastShotTime = 0;

    /**
     * Cooldown period (in milliseconds) required between consecutive player shots.
     */
    private final long shotCooldown = 500;

    /**
     * Label displaying the score table.
     */
    private Label scoreTableLabel;

    /**
     * Animation timer controlling the main game loop, including updates and rendering.
     */
    private AnimationTimer gameLoop;

    /**
     * Timeline used to periodically check for collisions between game objects.
     */
    private Timeline collisionCheck;

    /**
     * Constructor to create a new GameController.
     *
     * @param root  the root pane where game elements will be added
     * @param scene the JavaFX scene used for key input
     */
    public GameController(Pane root, Scene scene) {
        this.root = root;
        this.scene = scene;
        this.enemies = new ArrayList<>();
    }
    /**
     * Initializes and starts the game including map, player tank,
     * UI elements, enemies and control setup.
     */
    public void startGame() {
        map = new GameMap();
        map.drawWalls(root);
        double startX = (double) (Main.WIDTH * Main.TILE_SIZE - 40) / 2;
        double startY = Main.HEIGHT * Main.TILE_SIZE - 50;
        player = new PlayerTank(root, startX, startY);
        setupControls();
        spawnEnemy();
        startEnemyFireLoop();
        if (collisionCheck != null) collisionCheck.stop();
        startPlayerEnemyCollisionCheck();
        scoreLabel = new Label("Score: 0");
        scoreLabel.setStyle("-fx-font-size: 14px; -fx-text-fill: red;");
        scoreLabel.setLayoutX(20);
        scoreLabel.setLayoutY(20);

        livesLabel = new Label("Lives: " + player.getLives());
        livesLabel.setStyle("-fx-font-size: 14px; -fx-text-fill: red;");
        livesLabel.setLayoutX(20);
        livesLabel.setLayoutY(40);

        root.getChildren().addAll(scoreLabel, livesLabel);

    }
    /**
     * Sets up keyboard controls for player movement, shooting, pausing,
     * restarting and exiting the game.
     */
    private void setupControls() {
        scene.setOnKeyPressed(e -> {
            pressedKeys.add(e.getCode());
            if (e.getCode() == KeyCode.ESCAPE && isGameOver()) {
                Platform.exit();
            }
            if (e.getCode() == KeyCode.R && isGameOver()) {
                restartGame(root,enemies);

            }if (player.getLives()>0){
            if (e.getCode() == KeyCode.P) {
                pauseMenu = new Label("      MENU:"+"\nYour Score: " + score + "\n\nPress R to restart!" + "\nPress ESC to close!");
                pauseMenu.setStyle("-fx-font-size: 16px; -fx-text-fill: red;");
                Button continueButton = new Button("Continue");
                continueButton.setLayoutX(320);
                continueButton.setLayoutY(340);
                continueButton.setOnAction(event -> {
                    root.getChildren().remove(pauseMenu);
                    root.getChildren().remove(continueButton);
                    root.requestFocus();
                    setGameOver(false);
                });
                pauseMenu.setLayoutX(320);
                pauseMenu.setLayoutY(240);

                root.getChildren().addAll(pauseMenu, continueButton);
                root.requestFocus();
                setGameOver(true);
            }}
        });
        scene.setOnKeyReleased(e -> {
            pressedKeys.remove(e.getCode());
        });
        // Main game loop
        if (gameLoop != null) gameLoop.stop();
        gameLoop = new AnimationTimer()  {
            @Override
            public void handle(long now) {
                if (isGameOver) return;
                // Movement controls
                if (pressedKeys.contains(KeyCode.UP)) {
                    player.move(0, -1, map.getWalls());
                    player.getTankImage().setRotate(270);
                } else if (pressedKeys.contains(KeyCode.DOWN)) {
                    player.move(0, 1, map.getWalls());
                    player.getTankImage().setRotate(90);
                } else if (pressedKeys.contains(KeyCode.LEFT)) {
                    player.move(-1, 0, map.getWalls());
                    player.getTankImage().setRotate(180);
                } else if (pressedKeys.contains(KeyCode.RIGHT)) {
                    player.move(1, 0, map.getWalls());
                    player.getTankImage().setRotate(0);
                }
                // Shooting
                if (pressedKeys.contains(KeyCode.X)) {
                    long currentTime = System.currentTimeMillis();
                    if (currentTime - lastShotTime >= shotCooldown) {
                        lastShotTime = currentTime;
                        double bulletX = player.getTankImage().getLayoutX() + 15;
                        double bulletY = player.getTankImage().getLayoutY() + 15;

                        int dx = 0, dy = 0;
                        double angle = player.getTankImage().getRotate();
                        if (angle == 0) dx = 1;
                        else if (angle == 90) dy = 1;
                        else if (angle == 180) dx = -1;
                        else if (angle == 270) dy = -1;

                        new Bullet(root, bulletX, bulletY, dx, dy, map.getWalls(), enemies, GameController.this, player, true, null);
                    }
                }
            }
        };

        gameLoop.start();

    }
    /**
     * Starts the enemy tank shooting mechanism using a recurring timeline.
     */
    private void startEnemyFireLoop() {
        enemyFireTimeline = new Timeline(new KeyFrame(Duration.seconds(1), e -> {
            for (EnemyTank enemy : enemies) {
                double bulletX = enemy.getTankImage().getLayoutX() + 15;
                double bulletY = enemy.getTankImage().getLayoutY() + 15;
                int dx = 0, dy = 0;
                double angle = enemy.getTankImage().getRotate();

                if (angle == 0) dx = 1;
                else if (angle == 90) dy = 1;
                else if (angle == 180) dx = -1;
                else if (angle == 270) dy = -1;

                new Bullet(root, bulletX, bulletY, dx, dy, map.getWalls(), enemies, this, player,false,enemy);
            }
        }));
        enemyFireTimeline.setCycleCount(Timeline.INDEFINITE);
        enemyFireTimeline.play();
    }
    /**
     * Spawns enemy tanks at random positions, ensuring they do not intersect walls.
     */
    public void spawnEnemy() {
        while (enemies.size() < MAX_ENEMIES ) {
            double x = random.nextInt(Main.WIDTH * Main.TILE_SIZE - 40);
            double y = 60;
            EnemyTank enemy = new EnemyTank(root, x, y, map.getWalls(),this);
            boolean intersects = false;
            for (ImageView wall : map.getWalls()) {
                if (enemy.getTankImage().getBoundsInParent().intersects(wall.getBoundsInParent())) {
                    intersects = true;
                    break;
                }
            }
            if (!intersects) {
                enemies.add(enemy);
            } else {
                root.getChildren().remove(enemy.getTankImage());
            }

        }
    }

    /**
     * Restarts the game by resetting the score, player, enemies, and UI elements.
     *
     * @param root    the game root pane
     * @param enemies the list of enemy tanks to clear
     */
    public void restartGame(Pane root, List<EnemyTank> enemies) {
        if (enemyFireTimeline != null) enemyFireTimeline.stop();
        setScore(0);
        root.getChildren().clear();
        enemies.clear();
        setGameOver(false);
        startGame();
    }
    /**
     * Checks for collisions between the player and enemy tanks.
     * Triggers explosions and life reduction or game over.
     */
    public void tankCollision(){
        if (!isGameOver) {
            for (EnemyTank enemy : new ArrayList<>(enemies)) {
                if (player.getTankImage().getBoundsInParent().intersects(enemy.getTankImage().getBoundsInParent())) {
                    if (player.getLives()>1){
                    explodeEnemy(root, enemy.getTankImage());
                    explodePlayer(root, player.getTankImage());
                    updateScore(1);
                    player.loseLife();
                    updateLives(player.getLives());
                    root.getChildren().remove(enemy.getTankImage());
                    enemies.remove(enemy);
                    spawnEnemy();
                    player.resetToStart();
                    }else {
                        explodeEnemy(root, enemy.getTankImage());
                        explodePlayer(root, player.getTankImage());
                        updateScore(1);
                        player.loseLife();
                        updateLives(player.getLives());
                        gameOver();}
                }}

                }}
    /**
     * Starts a timeline that periodically checks for player-enemy collisions.
     */
    private void startPlayerEnemyCollisionCheck() {
        Timeline collisionCheck = new Timeline(new KeyFrame(Duration.millis(100), e -> {
            tankCollision();
        }));
        collisionCheck.setCycleCount(Timeline.INDEFINITE);
        collisionCheck.play();
    }
    /**
     * Ends the game and shows the "Game Over" screen with score and restart options.
     */
    public void gameOver(){
        setGameOver(true);
        scoreTableLabel = new Label("  GAME OVER!\n" + "Your Score: " + getScore() + "\n\nPress R to restart!"+ "\nPress ESC to close!");
        scoreTableLabel.setStyle("-fx-font-size: 16px; -fx-text-fill: red;");
        scoreTableLabel.setLayoutX(320);
        scoreTableLabel.setLayoutY(240);
        root.getChildren().add(scoreTableLabel);
        root.requestFocus();
    }

    /**
     * Creates a large explosion effect at the player's position.
     *
     * @param root the game pane
     * @param playerImage the player's tank image view
     */
    public void explodePlayer(Pane root, ImageView playerImage) {
        Image explosion = new Image(getClass().getResource("/explosion.png").toExternalForm());
        ImageView effect = new ImageView(explosion);
        effect.setLayoutX(playerImage.getLayoutX());
        effect.setLayoutY(playerImage.getLayoutY());
        effect.setFitWidth(40);
        effect.setFitHeight(40);
        root.getChildren().add(effect);

        new Timeline(new KeyFrame(Duration.millis(700), e -> root.getChildren().remove(effect))).play();
    }
    /**
     * Creates a large explosion effect at an enemy tank's position.
     *
     * @param root the game pane
     * @param enemyTank  the enemy tank's image view
     */
    public void explodeEnemy(Pane root, ImageView enemyTank) {
        Image explosion = new Image(Objects.requireNonNull(getClass().getResource("/explosion.png")).toExternalForm());
        ImageView effect = new ImageView(explosion);
        effect.setLayoutX(enemyTank.getLayoutX());
        effect.setLayoutY(enemyTank.getLayoutY());
        effect.setFitWidth(40);
        effect.setFitHeight(40);
        root.getChildren().add(effect);

        new Timeline(new KeyFrame(Duration.millis(300), e -> root.getChildren().remove(effect))).play();
    }
    /**
     * Creates a small explosion effect at the wall's position.
     *
     * @param root the game pane
     * @param wall the wall image view
     */
    public void explodeWall(Pane root, ImageView wall) {
        Image explosion = new Image(Objects.requireNonNull(getClass().getResource("/smallExplosion.png")).toExternalForm());
        ImageView effect = new ImageView(explosion);
        double x = wall.getBoundsInParent().getMinX();
        double y = wall.getBoundsInParent().getMinY();
        effect.setLayoutX(x);
        effect.setLayoutY(y);
        effect.setFitWidth(20);
        effect.setFitHeight(20);
        root.getChildren().add(effect);

        new Timeline(new KeyFrame(Duration.millis(300), e -> root.getChildren().remove(effect))).play();
    }
    /**
     * Updates the score and the score label on the UI.
     *
     * @param value the amount to add to the current score
     */
    public void updateScore(int value) {
        score += value;
        scoreLabel.setText("Score: " + score);
    }
    /**
     * Updates the lives label with the current number of lives.
     *
     * @param lives the remaining lives of the player
     */
    public void updateLives(int lives) {
        livesLabel.setText("Lives: " + lives);
    }
    /**
     * Returns the current score.
     *
     * @return the score
     */
    public int getScore() {
        return score;
    }
    /**
     * Sets the current score to the specified value.
     *
     * @param score the new score value
     */
    public void setScore(int score) {
        this.score = score;
    }/**
     * Checks if the game is over.
     *
     * @return true if the game is over, false otherwise
     */
    public boolean isGameOver() {
        return isGameOver;
    }
    /**
     * Sets the game over state.
     *
     * @param gameOver true to end the game, false to resume
     */
    public void setGameOver(boolean gameOver) {
        isGameOver = gameOver;
    }
}

