import javafx.scene.image.ImageView;
import java.util.List;

/**
 * Interface representing a tank in the game.
 * Defines basic behaviors like movement, getting the tank's image, and animating the tank's wheels.
 */
public interface Tank {
    /**
     * A static number used for animation or tracking purposes.
     */
    int number = 0;

    /**
     * Moves the tank by the specified delta values while considering collision with walls.
     *
     * @param dx The change in the x-direction (horizontal movement).
     * @param dy The change in the y-direction (vertical movement).
     * @param walls A list of ImageView objects representing walls to check for collisions.
     */
    void move(int dx, int dy, List<ImageView> walls);

    /**
     * Returns the ImageView representing the tank's graphical representation.
     *
     * @return The ImageView of the tank.
     */
    ImageView getTankImage();

    /**
     * Animates the tank's wheels, typically by alternating images or applying visual effects.
     */
    void animateWheels();
}

