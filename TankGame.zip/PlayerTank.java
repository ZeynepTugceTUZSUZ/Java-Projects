import javafx.scene.layout.Pane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import java.util.List;
/**
 * Represents the player's tank in the game.
 * Handles movement, collision with walls, animation, lives, and reset logic.
 */
public class PlayerTank implements Tank {
    /** Speed of the tank movement */
    private double speed = 0.75;

    /** Number of lives the player has */
    private int lives = 3;

    /** ImageView that represents the tank's appearance on screen */
    private ImageView tankImage;

    /** First image used for tank animation */
    private Image image;

    /** Second image used for tank animation */
    private Image image1;

    /** Counter used for alternating between tank images for animation */
    private int number = 0;

    /**
     * Constructs a PlayerTank and places it on the given pane at specified coordinates.
     *
     * @param pane The pane to add the tank to.
     * @param x The initial X coordinate.
     * @param y The initial Y coordinate.
     */
    public PlayerTank(Pane pane, double x, double y) {
        image = new Image(getClass().getResource("/whiteTank1.png").toExternalForm());
        image1 = new Image(getClass().getResource("/whiteTank2.png").toExternalForm());
        tankImage = new ImageView(image);
        tankImage.setFitWidth(30);
        tankImage.setFitHeight(30);
        tankImage.setLayoutX(x);
        tankImage.setLayoutY(y);
        pane.getChildren().add(tankImage);
    }
    /**
     * Moves the tank in the given direction, while checking for wall collisions.
     * If a collision occurs, the move is canceled.
     *
     * @param x Direction of movement along the X-axis (-1, 0, or 1).
     * @param y Direction of movement along the Y-axis (-1, 0, or 1).
     * @param walls List of wall objects to check collisions against.
     */

    public void move(int x, int y, List<ImageView> walls) {
        double nextX = tankImage.getLayoutX() + x * speed;
        double nextY = tankImage.getLayoutY() + y * speed;

        tankImage.setLayoutX(nextX);
        tankImage.setLayoutY(nextY);
        animateWheels();
        for (ImageView wall : walls) {
            if (tankImage.getBoundsInParent().intersects(wall.getBoundsInParent())) {
                tankImage.setLayoutX(tankImage.getLayoutX() - x * speed);
                tankImage.setLayoutY(tankImage.getLayoutY() - y * speed);
                return;
            }
        }
    }
    /**
     * Resets the tank to its starting position at the bottom center of the screen.
     */
    public void resetToStart() {
        tankImage.setLayoutX((double) (Main.WIDTH * Main.TILE_SIZE - 40) / 2);
        tankImage.setLayoutY(Main.HEIGHT * Main.TILE_SIZE - 50);
    }
    /**
     * Decreases the tank's lives by one.
     */
    public void loseLife() {
        lives--;
    }
    /**
     * Returns the number of lives remaining.
     *
     * @return Current number of lives.
     */

    public int getLives() {
        return lives;
    }
    /**
     * Returns the ImageView representing the tank.
     *
     * @return ImageView of the tank.
     */

    public ImageView getTankImage() {
        return tankImage;
    }/**
     * Alternates between two images to simulate wheel animation.
     * This is called on every movement update.
     */
    public void animateWheels(){
        if (number%2==0){
            tankImage.setImage(image);
        }
        else {tankImage.setImage(image1);}
        number++;
    }
}
