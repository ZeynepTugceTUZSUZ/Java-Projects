import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.Pane;
import javafx.util.Duration;
import java.util.List;
import java.util.Objects;
/**
 * The {@code Bullet} class represents a bullet fired by either the player or enemy tanks.
 * It handles movement, collision detection with walls, enemies, and the player, and triggers
 * explosions and related game logic upon impact.
 */
public class Bullet {
    private ImageView imageView;
    private Timeline timeline;
    private double speed = 10;
    private int dx, dy;
    private GameController gameController;
    private PlayerTank playerTank;
    private EnemyTank shooterEnemy;
    /**
     * Constructs a Bullet instance and starts its movement.
     *
     * @param root The pane where the bullet will be rendered.
     * @param x The initial X position of the bullet.
     * @param y The initial Y position of the bullet.
     * @param dx The horizontal movement direction (-1, 0, or 1).
     * @param dy The vertical movement direction (-1, 0, or 1).
     * @param walls The list of wall ImageViews in the game.
     * @param enemies The list of enemy tanks in the game.
     * @param gameController Reference to the game controller for accessing game logic.
     * @param playerTank Reference to the player's tank.
     * @param isPlayerBullet {@code true} if fired by the player, {@code false} if fired by an enemy.
     * @param shooterEnemy The enemy tank that fired the bullet (if applicable).
     */
    public Bullet(Pane root, double x, double y, int dx, int dy, List<ImageView> walls, List<EnemyTank> enemies,GameController gameController,PlayerTank playerTank,boolean isPlayerBullet,EnemyTank shooterEnemy) {
        this.gameController = gameController;
        this.playerTank = playerTank;
        this.shooterEnemy = shooterEnemy;
        Image bulletImage = new Image(Objects.requireNonNull(getClass().getResource("/bullet.png")).toExternalForm());
        imageView = new ImageView(bulletImage);
        imageView.setFitWidth(5);
        imageView.setFitHeight(5);
        imageView.setLayoutX(x);
        imageView.setLayoutY(y);
        root.getChildren().add(imageView);
        this.dx = dx;
        this.dy = dy;
        timeline = new Timeline(new KeyFrame(Duration.millis(30), e -> move(root, walls, enemies,gameController,playerTank,isPlayerBullet,shooterEnemy)));
        timeline.setCycleCount(Timeline.INDEFINITE);
        timeline.play();
    }
    /**
     * Moves the bullet based on its direction and handles collision detection with walls,
     * enemies, and the player.
     *
     * @param root The game pane.
     * @param walls The list of walls in the game.
     * @param enemies The list of enemy tanks.
     * @param gameController The game controller.
     * @param playerTank The player's tank.
     * @param isPlayerBullet Whether the bullet was fired by the player.
     * @param shooterEnemy The enemy tank that shot the bullet, if applicable.
     */
    private void move(Pane root, List<ImageView> walls, List<EnemyTank> enemies,GameController gameController,PlayerTank playerTank,boolean isPlayerBullet,EnemyTank shooterEnemy) {
        if (gameController.isGameOver()) {
            return;
        }
        imageView.setLayoutX(imageView.getLayoutX() + dx * speed);
        imageView.setLayoutY(imageView.getLayoutY() + dy * speed);

        // Check for wall collision
        for (ImageView wall : walls) {
            if (imageView.getBoundsInParent().intersects(wall.getBoundsInParent())) {
                gameController.explodeWall(root, wall);
                destroy(root);
                return;}
        }
        // Check for collision with enemy tanks (if fired by player)
        if (isPlayerBullet){
        for (EnemyTank enemy : enemies) {
            if (enemy != shooterEnemy && imageView.getBoundsInParent().intersects(enemy.getTankImage().getBoundsInParent())) {
                gameController.explodeEnemy(root,
                        enemy.getTankImage());
                root.getChildren().remove(enemy.getTankImage());
                enemies.remove(enemy);
                destroy(root);
                gameController.spawnEnemy();
                gameController.updateScore(1);
                return;}
        }}
        // Check for collision with player tank (if fired by enemy)
        if (!isPlayerBullet && playerTank.getLives()>0){
        if (imageView.getBoundsInParent().intersects(playerTank.getTankImage().getBoundsInParent())) {
            gameController.explodePlayer(root, playerTank.getTankImage());
            root.getChildren().remove(imageView);
            if (!gameController.isGameOver){
            playerTank.loseLife();}
            gameController.updateLives(playerTank.getLives());
            playerTank.resetToStart();
            if (playerTank.getLives() <= 0) {
                gameController.gameOver();
                root.setOnKeyPressed(event -> {
                    if (event.getCode() == KeyCode.R && gameController.isGameOver()) {
                        gameController.restartGame(root,enemies);
                    }
                });
                root.requestFocus();
            }
            timeline.stop();
        }}
    }
    /**
     * Stops the bullet's movement and removes it from the scene.
     *
     * @param root The game pane.
     */
    private void destroy(Pane root) {
        timeline.stop();
        root.getChildren().remove(imageView);
    }


}

