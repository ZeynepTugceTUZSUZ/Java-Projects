import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
/**
 * The main entry point for the Tank Game application.
 * This class sets up the primary stage, scene, and initializes the game controller.
 */
public class Main extends Application {
    /**
     * The size of each tile in pixels.
     */
    public static final int TILE_SIZE = 20;

    /**
     * The number of tiles horizontally.
     */
    public static final int WIDTH = 40;

    /**
     * The number of tiles vertically.
     */
    public static final int HEIGHT = 30;

    /**
     * Starts the JavaFX application by setting up the window, scene, and initializing the game.
     *
     * @param primaryStage the primary stage for this application, onto which
     *                     the application scene can be set.
     */
    @Override
    public void start(Stage primaryStage) {
        Pane root = new Pane();
        root.setStyle("-fx-background-color: #00CED1;");// Set background color of the game

        Scene scene = new Scene(root, WIDTH * TILE_SIZE, HEIGHT * TILE_SIZE);
        GameController controller = new GameController(root, scene);
        controller.startGame();// Initialize and start the game

        primaryStage.setTitle("Tank Game");
        primaryStage.setScene(scene);
        primaryStage.show(); // Display the primary stage
    }
    /**
     * The main method to launch the JavaFX application.
     *
     * @param args command line arguments (not used)
     */
    public static void main(String[] args) {
        launch(args);// Launch the JavaFX application
    }
}
