import java.util.Stack;

public class QuickSort {
    public static void sort(int[] array, int lo, int hi)
    {
        int pivot;
        int stackSize = hi - lo +1;
        int[] stack = new int[stackSize];
        int top = -1;
        stack[++top] = lo;
        stack[++top] = hi;

        while (top>=0)
        {
            hi = stack[top--];
            lo = stack[top--];
            pivot = partition(array,lo,hi);
            if (pivot-1>lo)
            {
                stack[++top] = lo;
                stack[++top] = pivot -1;
            }
            if(pivot+1<hi)
            {
                stack[++top] = pivot +1;
                stack[++top] = hi;
            }
        }
    }

    public static int partition(int[] array, int lo, int hi)
    {
        int pivot = array[hi];
        int i = lo -1;
        for (int j=lo; j<=hi-1; j++)
        {
            if (array[j]<=pivot)
            {
                ++i;
                swap(array, i, j);
            }
        }
        swap(array,i+1,hi);
        return i+1;//pivotun indexi
    }
    public static void swap(int[]array,int x, int y)
    {
        int swap = array[x];
        array[x] = array[y];
        array[y] = swap;
    }
}
