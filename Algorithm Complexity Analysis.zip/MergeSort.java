public class MergeSort {
    public static void sort(int[] array)
    {
        int n = array.length;
        int[] temp = new int[n];
        int currSize = 1;
        while (currSize<n)
        {
            int lst = 0;
            while (lst<n-1)
            {
                int mid = min(lst + currSize-1,n-1);
                int rend = min (lst + 2*currSize-1,n-1);
                merge(array,temp,lst,mid,rend);
                lst = lst + 2*currSize;
            }
            currSize *=2;
        }

    }
    public static int min(int x, int y)
    {
        return (x<y) ? x : y;
    }
    public static void merge(int[] array,int[] temp,int left, int mid ,int right)
    {
        int i = left;
        int j = mid + 1;
        int k = left;
        while (i<= mid && j<=right)
        {
            if (array[i] <= array[j]) {
                temp[k] = array[i];
                i++;
            }
            else{
                temp[k] = array[j];
                j++;
            }k++;
        }
        while (i<=mid)
        {
            temp[k] = array[i];
            i++;
            k++;
        }
        while (j<=right)
        {
            temp[k] = array[j];
            j++;
            k++;
        }
        for (int x = left;x<=right;x++)
        {
            array[x] = temp[x];
        }

    }
}
