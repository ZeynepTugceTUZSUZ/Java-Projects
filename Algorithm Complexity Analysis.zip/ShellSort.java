public class ShellSort {
    public static void sort(int[] array)
    {
        int n = array.length;
        int h = 1;
        while (h<n/3)
        {
            h = 3*h +1;
        }
        while (h>=1)
        {
            for (int i =h;i<=n-1;i++)
            {
                int j=i;
                while (j>=h && less(array[j],array[j-h]))
                {
                    exch(array,j,j-h);
                    j -= h;
                }
            }h /= 3;
        }
    }
    public static boolean less(int x, int y)
    {
        return x<y;
    }
    public static void exch(int[] array, int x, int y)
    {
        int swap = array[x];
        array[x] = array[y];
        array[y] = swap;
    }
}
