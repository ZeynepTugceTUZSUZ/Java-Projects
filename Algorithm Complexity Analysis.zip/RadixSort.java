public class RadixSort {
    public static int[] sort(int[] array,int d)
    {
        for (int pos = 1;pos<=d;pos++)
            array = countingSort(array,pos);
        return array;
    }
    public static int[] countingSort(int[] array,int pos)
    {
        int[] count = new int[10];
        int size = array.length;
        int[] output = new int[size];
        int digit;
        for (int i = 0;i<size;i++)
        {
            digit = getDigit(array[i],pos);
            count[digit] += 1;
        }
        for (int i = 1;i<10;i++)
        {
            count[i] += count[i-1];
        }
        for (int i = size-1;i>=0;i--)
        {
            digit = getDigit(array[i],pos);
            count[digit] -= 1;
            output[count[digit]] = array[i];
        }
        return output;
    }
    public static int getDigit(int x,int pos)
    {
        return (x / (int)Math.pow(10, pos-1)) % 10;
    }
}
