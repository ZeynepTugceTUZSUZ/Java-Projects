import org.knowm.xchart.*;
import org.knowm.xchart.style.Styler;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;

public class Main {

    public static void main(String[] args) throws IOException {

        String filePath = "src/all_stocks_5yr.csv";
        List<Integer> volumeList = readVolumesFromCSV(filePath);
        int[] fullData = volumeList.stream().mapToInt(i -> i).toArray();
        System.out.println("Toplam kayıt:" + fullData.length);

        int[] testSizes = {500, 1000, 2000, 4000, 8000, 16000, 32000, 64000, 128000, 250000};

        Map<String, List<Double>> randomTimes = new HashMap<>();
        Map<String, List<Double>> sortedTimes = new HashMap<>();
        Map<String, List<Double>> reversedTimes = new HashMap<>();

        String[] algorithms = {"QuickSort", "MergeSort", "InsertionSort", "ShellSort", "RadixSort"};

        for (String algo : algorithms) {
            randomTimes.put(algo, new ArrayList<>());
            sortedTimes.put(algo, new ArrayList<>());
            reversedTimes.put(algo, new ArrayList<>());
        }

        List<Integer> xAxisSizes = new ArrayList<>();

        for (int size : testSizes) {

            if (size > fullData.length) break;

            int[] baseArray = Arrays.copyOfRange(fullData, 0, size);

            int[] randomArray = Arrays.copyOf(baseArray, size);
            int[] sortedArray = Arrays.copyOf(randomArray, size);
            Arrays.sort(sortedArray);

            int[] reversedArray = Arrays.copyOf(sortedArray, size);
            reverseArray(reversedArray);

            xAxisSizes.add(size);
            System.out.println("\n##### Input size: " + size + " #####");

            for (String algorithm : algorithms) {

                double randomTime = measureAverageTime(randomArray, algorithm);
                double sortedTime = measureAverageTime(sortedArray, algorithm);
                double reversedTime = measureAverageTime(reversedArray, algorithm);

                randomTimes.get(algorithm).add(randomTime);
                sortedTimes.get(algorithm).add(sortedTime);
                reversedTimes.get(algorithm).add(reversedTime);

                System.out.println(algorithm + " => Random(ms): " + formatMs(randomTime)
                        + ", Sorted(ms): " + formatMs(sortedTime)
                        + ", Reversed(ms): " + formatMs(reversedTime));
            }
        }

        for (String algorithm : algorithms) {
            XYChart chart = new XYChartBuilder()
                    .width(800).height(600)
                    .title(algorithm + " Analysis")
                    .xAxisTitle("Input Size")
                    .yAxisTitle("Time (ms)")
                    .build();

            chart.getStyler().setLegendPosition(Styler.LegendPosition.InsideNE);
            chart.getStyler().setDefaultSeriesRenderStyle(XYSeries.XYSeriesRenderStyle.Line);

            double[] xArr = xAxisSizes.stream().mapToDouble(i -> i).toArray();

            chart.addSeries("Random Data", xArr, listToArray(randomTimes.get(algorithm)));
            chart.addSeries("Sorted Data", xArr, listToArray(sortedTimes.get(algorithm)));
            chart.addSeries("Reversed Data", xArr, listToArray(reversedTimes.get(algorithm)));

            BitmapEncoder.saveBitmap(chart, algorithm.replace("Sort", "_Sort_Analysis"), BitmapEncoder.BitmapFormat.PNG);
        }

        String[] dataTypes = {"Random Data", "Sorted Data", "Reversed Data"};
        Map<String, Map<String, List<Double>>> dataMap = new HashMap<>();
        dataMap.put("Random Data", randomTimes);
        dataMap.put("Sorted Data", sortedTimes);
        dataMap.put("Reversed Data", reversedTimes);

        for (String dataType : dataTypes) {
            XYChart chart = new XYChartBuilder()
                    .width(800).height(600)
                    .title(dataType + " Comparison")
                    .xAxisTitle("Input Size")
                    .yAxisTitle("Time (ms)")
                    .build();

            chart.getStyler().setLegendPosition(Styler.LegendPosition.InsideNE);
            chart.getStyler().setDefaultSeriesRenderStyle(XYSeries.XYSeriesRenderStyle.Line);

            double[] xArr = xAxisSizes.stream().mapToDouble(i -> i).toArray();

            for (String algorithm : algorithms) {
                chart.addSeries(algorithm, xArr, listToArray(dataMap.get(dataType).get(algorithm)));
            }

            BitmapEncoder.saveBitmap(chart, dataType.replace(" ", "_") + "_Comparison", BitmapEncoder.BitmapFormat.PNG);
        }
        createLogarithmicChart("Random Data Comparison", xAxisSizes, randomTimes, "Random_Data_Comparison");
        createLogarithmicChart("Sorted Data Comparison", xAxisSizes, sortedTimes, "Sorted_Data_Comparison");
        createLogarithmicChart("Reversed Data Comparison", xAxisSizes, reversedTimes, "Reversed_Data_Comparison");
    }

    private static void createLogarithmicChart(String title,
                                               List<Integer> xAxisSizes,
                                               Map<String, List<Double>> data,
                                               String fileName) throws IOException {

        XYChart chart = new XYChartBuilder()
                .width(800).height(600)
                .title(title + " (Logarithmic Scale)")
                .xAxisTitle("Input Size (n)")
                .yAxisTitle("Time (ms)")
                .build();

        chart.getStyler().setYAxisLogarithmic(true);

        chart.getStyler().setLegendPosition(Styler.LegendPosition.InsideNE);
        chart.getStyler().setDefaultSeriesRenderStyle(XYSeries.XYSeriesRenderStyle.Line);

        double[] xArr = xAxisSizes.stream().mapToDouble(i -> i).toArray();

        for (String algorithm : data.keySet()) {
            double[] safeY = data.get(algorithm).stream()
                    .mapToDouble(Main::safeValue)
                    .toArray();

            chart.addSeries(algorithm, xArr, safeY);
        }

        BitmapEncoder.saveBitmap(chart, fileName + "_LOG", BitmapEncoder.BitmapFormat.PNG);
    }

    private static double safeValue(double val) {
        return val <= 0 ? 0.0001 : val;
    }

    private static double[] listToArray(List<Double> list) {
        double[] arr = new double[list.size()];
        for (int i = 0; i < list.size(); i++) arr[i] = list.get(i);
        return arr;
    }

    private static List<Integer> readVolumesFromCSV(String filePath) {
        List<Integer> volumes = new ArrayList<>();
        try {
            Files.lines(Paths.get(filePath))
                    .skip(1)
                    .forEach(line -> {
                        String[] cols = line.split(",");
                        if (cols.length >= 6) {
                            try {
                                volumes.add(Integer.parseInt(cols[5].trim()));
                            } catch (NumberFormatException e) {
                                System.out.println("Hatalı satır:" + line);
                            }
                        }
                    });
        } catch (IOException e) {
            e.printStackTrace();
        }
        return volumes;
    }

    private static void reverseArray(int[] arr) {
        for (int i = 0; i < arr.length / 2; i++) {
            int temp = arr[i];
            arr[i] = arr[arr.length - 1 - i];
            arr[arr.length - 1 - i] = temp;
        }
    }

    private static double measureAverageTime(int[] arr, String algorithm) {
        long totalTime = 0;
        for (int i = 0; i < 10; i++) {
            int[] tempArray = Arrays.copyOf(arr, arr.length);
            long startTime = System.nanoTime();
            applySorting(tempArray, algorithm);
            long endTime = System.nanoTime();
            totalTime += (endTime - startTime);
        }
        return totalTime / 10.0 / 1_000_000.0;
    }

    private static void applySorting(int[] array, String algorithm) {
        switch (algorithm) {
            case "QuickSort":
                QuickSort.sort(array, 0, array.length - 1);
                break;
            case "MergeSort":
                MergeSort.sort(array);
                break;
            case "InsertionSort":
                InsertionSort.sort(array);
                break;
            case "ShellSort":
                ShellSort.sort(array);
                break;
            case "RadixSort":
                int max = Arrays.stream(array).max().getAsInt();
                int digitCount = Integer.toString(max).length();
                int[] sorted = RadixSort.sort(array, digitCount);
                System.arraycopy(sorted, 0, array, 0, array.length);
                break;
        }
    }

    private static String formatMs(double time) {
        return String.format(Locale.US, "%.3f", time);
    }
}