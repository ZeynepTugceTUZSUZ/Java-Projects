import java.util.Map;

public class CostHelper {

    public static String[] computeDerivedCost(DiagnosticCatalogue.Test test, Map<String, Integer> costTable){
        int sum = test.cost;
        String s_sum = "";
        if (test.cost != 0) {s_sum = test.cost + " + ";}
        for (String input : test.inputs) {
            Integer inputCost = costTable.get(input);
            if (inputCost != null) {
                sum += inputCost;
                s_sum += inputCost + " + ";
            }
        }
        if (s_sum.endsWith(" + "))
            s_sum = s_sum.substring(0, s_sum.length()-2);
        return new String[] {String.valueOf(sum), s_sum};
    }
    public static String[] computeCompositeCost(DiagnosticCatalogue.Test test, Map<String, Integer> costTable){
        int sum = 0;
        String s_sum = "";
        for (String input : test.inputs) {
            Integer inputCost = costTable.get(input);
            if (inputCost != null) {
                sum += inputCost;
                s_sum += inputCost + " + ";
            }
        }
        if (s_sum.endsWith("+ "))
            s_sum = s_sum.substring(0, s_sum.length()-2);
        return new String[] {String.valueOf(sum), s_sum};
    }
}
