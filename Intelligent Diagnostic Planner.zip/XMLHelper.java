import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;

public class XMLHelper {
    public static org.w3c.dom.Document loadDocument(String filePath) throws ParserConfigurationException {

        try {
            javax.xml.parsers.DocumentBuilderFactory fac = javax.xml.parsers.DocumentBuilderFactory.newInstance();

            javax.xml.parsers.DocumentBuilder build = fac.newDocumentBuilder();

            org.w3c.dom.Document doc = build.parse(new java.io.File(filePath));

            doc.getDocumentElement().normalize();

            return doc;

        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (SAXException e) {
            throw new RuntimeException(e);
        }
    }
}
