import java.util.*;

/**
 * DiagnosticCatalogue
 *
 * Responsible for:
 *   Step 1 -- loadFromXML()
 *             Parses diagnostic_catalogue.xml and builds the test map.
 *
 *   Step 2 -- computeDerivedCosts()
 *             Computes processing_cost for DERIVED tests.
 *             DERIVED tests depend exclusively on RAW tests.
 *             COMPOSITE tests always have no processing_cost.
 */
public class DiagnosticCatalogue {

    // =========================================================================
    // Inner class -- do NOT change field names or types
    // =========================================================================
    /**
     * Represents a single diagnostic test in the catalogue.
     *
     * RAW tests:
     *   - sampleType is one of: BLOOD, URINE, TISSUE, NONE
     *   - cost is the collection_cost read from XML
     *   - inputs is empty
     *
     * DERIVED tests:
     *   - sampleType is null (not applicable)
     *   - cost is computed by computeDerivedCosts() in Step 2
     *   - inputs contains only RAW test IDs
     *
     * COMPOSITE tests:
     *   - sampleType is null (not applicable)
     *   - initial cost is 0 (pure aggregation, no processing cost of its own)
     *   - inputs contains only DERIVED or COMPOSITE test IDs
     */
    public static class Test {

        public String       id;
        public String       name;
        public String       type;        // "RAW", "DERIVED", or "COMPOSITE"
        public String       sampleType;  // meaningful for RAW only
        public int          cost;        // collection_cost (RAW) or processing_cost (DERIVED) or 0 (COMPOSITE)
        public List<String> inputs;      // direct dependency IDs (empty for RAW)

        public Test() {
            inputs = new ArrayList<>();
        }

        /** Returns true if this test is of type RAW. */
        public boolean isRaw() {
            return "RAW".equalsIgnoreCase(type);
        }

        /** Returns true if this test is of type DERIVED. */
        public boolean isDerived() {
            return "DERIVED".equalsIgnoreCase(type);
        }

        /** Returns true if this test is of type COMPOSITE. */
        public boolean isComposite() {
            return "COMPOSITE".equalsIgnoreCase(type);
        }

        @Override
        public String toString() {
            return id + " [" + type + ", cost=" + cost + "]";
        }
    }

    // =========================================================================
    // Fields -- do NOT change names or types
    // =========================================================================
    /**
     * All tests in the catalogue, keyed by test ID.
     * Populated by loadFromXML(). LinkedHashMap preserves XML insertion order
     * which keeps output deterministic.
     */
    private Map<String, Test> tests = new LinkedHashMap<>();

    // =========================================================================
    // Step 1 -- TODO: implement this method
    // =========================================================================
    /**
     * Parses diagnostic_catalogue.xml and populates the tests map.
     * Uses standard Java javax.xml.parsers -- no external libraries.
     *
     * XML format:
     *   RAW:      <test id=".." name=".." type="RAW"
     *                   sample_type=".." collection_cost=".."/>
     *   DERIVED:  <test id=".." name=".." type="DERIVED">
     *               <input ref=".."/>  (only RAW refs)
     *             </test>
     *   COMPOSITE:<test id=".." name=".." type="COMPOSITE">
     *               <input ref=".."/>  (DERIVED or COMPOSITE refs)
     *             </test>
     *
     * @param filePath path to diagnostic_catalogue.xml
     */
    public void loadFromXML(String filePath) {
        // TODO: implement Step 1
        try {
            org.w3c.dom.Document doc = XMLHelper.loadDocument(filePath);
            org.w3c.dom.NodeList tests = doc.getElementsByTagName("test");
            for (int i = 0;i <= tests.getLength()-1 ;i++){
                org.w3c.dom.Element test_elements = (org.w3c.dom.Element) tests.item(i);
                String id = test_elements.getAttribute("id");
                String name = test_elements.getAttribute("name");
                String type = test_elements.getAttribute("type");

                if(type.equalsIgnoreCase("RAW")){
                    String sample_type = test_elements.getAttribute("sample_type");
                    int collection_cost = Integer.parseInt(test_elements.getAttribute("collection_cost"));
                    Test raw_test = new Test();
                    raw_test.id = id;
                    raw_test.name = name;
                    raw_test.type = type;
                    raw_test.sampleType = sample_type;
                    raw_test.cost = collection_cost;
                    this.tests.put(id,raw_test);

                }
                else{
                    org.w3c.dom.NodeList inputs = test_elements.getElementsByTagName("input");
                    List<String> input_refs = new ArrayList<>();
                    for (int j = 0; j <= inputs.getLength() -1; j++){
                        org.w3c.dom.Element input_elements = (org.w3c.dom.Element) inputs.item(j);
                        input_refs.add(input_elements.getAttribute("ref"));
                    }
                    Test der_or_com_test = new Test();
                    der_or_com_test.id = id;
                    der_or_com_test.name = name;
                    der_or_com_test.type = type;
                    der_or_com_test.inputs = input_refs;
                    this.tests.put(id,der_or_com_test);
                }
            }


        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // =========================================================================
    // Step 2 -- TODO: implement this method
    // =========================================================================
    /**
     * Computes and assigns processing_cost for every DERIVED test.
     *
     * Cost rule:
     *   DERIVED tests depend only on RAW tests directly.
     *   Iterate over the test's direct inputs
     *   Count the number of distinct non-NONE sample types among them.
     *   That count is the processing_cost.
     *
     * COMPOSITE tests are left at cost = 0 and must be skipped here. 
     * They are pure aggregations and carry no processing cost of their own.
     *
     * Prints a summary line for each DERIVED test:
     *   <id>    processing_cost: <value>
     * surrounded by ##COST COMPUTATION## markers.
     */
    public void computeDerivedCosts() {
        System.out.println("##COST COMPUTATION##");

        // TODO: implement Step 2
        // Use System.out.printf("%-25s processing_cost: %d%n", id, cost);
        for (Test value : tests.values()){
            if (value.isDerived()) {
                Set<String> cost = new HashSet<>();
                for (String id : value.inputs) {
                    if (tests.get(id) != null && !"NONE".equalsIgnoreCase(getTest(id).sampleType)) {
                        cost.add(getTest(id).sampleType);
                    }

                }
                value.cost = cost.size();
                System.out.printf("%-25s processing_cost: %d%n",value.id, cost.size());
            }
        }

        System.out.println("##COST COMPUTATION COMPLETED##");
        System.out.println();
    }

    // =========================================================================
    // Accessors -- do NOT change these
    // =========================================================================

    /** Returns the Test object for the given ID, or null if not found. */
    public Test getTest(String id) {
        return tests.get(id);
    }

    /** Returns an unmodifiable view of all tests in the catalogue. */
    public Map<String, Test> getAllTests() {
        return Collections.unmodifiableMap(tests);
    }
}
