/**
 * The Program class represents an academic program within a department.
 * It extends the AcademicEntity class.
 */
public class Program extends AcademicEntity{
    /** The description of the program. */
    private String description;

    /** The department to which the program belongs. */
    private String department;

    /** The degree level of the program (e.g., Bachelor, Master, PhD). */
    private String degreeLevel;

    /** The total number of credits required to complete the program. */
    private int totalCredits;

    /**
     * Constructs a Program object with the specified attributes.
     *
     * @param code The unique code of the program.
     * @param name The name of the program.
     * @param description The description of the program.
     * @param department  The department offering the program.
     * @param degreeLevel The degree level of the program.
     * @param totalCredits The total credits required for the program.
     */
    Program(String code, String name, String description, String department, String degreeLevel, int totalCredits) {
        super(code, name);
        this.description = description;
        this.department = department;
        this.degreeLevel = degreeLevel;
        this.totalCredits = totalCredits;
    }
    /**
     * Retrieves the total number of credits for the program.
     * @return The total number of credits.
     */
    public int getTotalCredits() {
        return totalCredits;
    }
    /**
     * Retrieves the degree level of the program.
     * @return The degree level of the program.
     */
    public String getDegreeLevel() {
        return degreeLevel;
    }
    /**
     * Retrieves the department offering the program.
     * @return The department of the program.
     */
    public String getDepartment() {
        return department;
    }
    /**
     * Retrieves the description of the program.
     * @return The description of the program.
     */
    public String getDescription() {
        return description;
    }
}