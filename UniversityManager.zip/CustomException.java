/**
 * CustomException is a class that contains multiple nested exception classes used
 * for handling various error scenarios within the student management system.
 */
public class CustomException {

    /**
     * Exception thrown when a specified person cannot be found in the system.
     */
    public static class PersonNotFoundException extends Exception{
        /**
         * Constructs a new PersonNotFoundException with the specified detail message.
         * @param message the detail message describing the exception.
         */
        public PersonNotFoundException(String message) {
            super(message);
        }
    }
    /**
     * Exception thrown when a specified course cannot be found in the system.
     */
    public static class CourseNotFoundException extends Exception{
        /**
         * Constructs a new CourseNotFoundException with the specified detail message.
         * @param message the detail message describing the exception.
         */
        public CourseNotFoundException(String message){
            super(message);
        }
    }
    /**
     * Exception thrown when a specified program cannot be found in the system.
     */
    public static class ProgramNotFoundException extends Exception{
        /**
         * Constructs a new ProgramNotFoundException with the specified detail message.
         * @param message the detail message describing the exception.
         */
        public ProgramNotFoundException(String message){
            super(message);
        }
    }
    /**
     * Exception thrown when an invalid person type is specified.
     */
    public static class InvalidPersonType extends Exception {
        /**
         * Constructs a new InvalidPersonType exception with the specified detail message.
         * @param message the detail message describing the exception.
         */
        public InvalidPersonType(String message) {
            super(message);
        }
    }
}
