import java.util.ArrayList;
import java.util.HashMap;
/**
 * Represents a student in the university system.
 * This class extends the Person class and provides specific functionalities for students,
 * such as tracking their assignments and grades.
 */
public class Student extends Person {
    /**
     * A HashMap to store the student's grades.
     * Key: Student ID
     * Value: A list of lists where each inner list contains course code and corresponding grade.
     */
    private HashMap<String, ArrayList<ArrayList<String>>> studentGrades;

    /**
     * A list of courses that the student is assigned to.
     */
    private ArrayList<String> assignments;

    /**
     * Constructs a Student object with the specified ID, name, email, and department.
     *
     * @param id The student's ID.
     * @param name The student's name.
     * @param email The student's email address.
     * @param department The department of the student.
     */
    Student(String id, String name, String email, String department) {
        super(id, name, email, department);
        studentGrades = new HashMap<>();
        assignments = new ArrayList<>();
    }
    /**
     * Adds an assignment (course) for the student.
     *
     * @param courseCode The code of the course to be assigned.
     */
    @Override
    public void assignment(String courseCode) {
        assignments.add(courseCode);
    }
    /**
     * Records a grade for a specific course for this student.
     *
     * @param letterGrade The letter grade earned (e.g., A, B, C).
     * @param courseCode The code of the course for which the grade is given.
     */
    public void studentGrade(String letterGrade,String courseCode) {
        ArrayList<String> tempList = new ArrayList<>();
        tempList.add(courseCode);
        tempList.add(letterGrade);
        studentGrades.putIfAbsent(getId(), new ArrayList<>());
        studentGrades.get(getId()).add(tempList);
    }
    /**
     * Provides a string representation of the student.
     *
     * @return A formatted string containing student information.
     */
    @Override
    public String toString() {
        return "Student ID: " + getId() + "\nName: " + getName() + "\nEmail: " + getEmail() + "\nMajor: " + getDepartment() + "\nStatus: Active";
    }
    /**
     * Retrieves the student's grades.
     *
     * @return A HashMap containing the student's grades.
     */
    public HashMap<String, ArrayList<ArrayList<String>>> getStudentGrades() {
        return studentGrades;
    }
    /**
     * Retrieves the list of courses assigned to the student.
     *
     * @return An ArrayList of assigned course codes.
     */
    public ArrayList<String> getAssignments() {
        return assignments;
    }
    /**
     * Provides a list of courses that the student is currently enrolled in but has not yet received grades for.
     *
     * @return An ArrayList of enrolled courses without grades.
     */
    public ArrayList<String> enrolledCourses() {
        ArrayList<String> gradedCourses = new ArrayList<>();
        ArrayList<String> enrolledCourses = new ArrayList<>();

        if (studentGrades.containsKey(getId())) {
            for (ArrayList<String> gradeInfo : studentGrades.get(getId())) {
                String courseCode = gradeInfo.get(0);
                gradedCourses.add(courseCode);}
        }
        for (String course : getAssignments()) {
            if (!gradedCourses.contains(course)) {
                enrolledCourses.add(course);
            }
        }
        return enrolledCourses;
    }

}
