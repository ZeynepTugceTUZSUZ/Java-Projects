import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.*;
/**
 * StudentManagementSystem class provides methods to manage and process student, faculty, department, program, and course information.
 * It supports reading data from text files, handling custom exceptions, and generating detailed reports.
 */
public class StudentManagementSystem {
    /**
     * HashMap to store department information with department code as key.
     */
    private HashMap<String, Department> department = new HashMap<>();

    /**
     * TreeMap to store program information with program code as key.
     */
    private TreeMap<String, Program> program = new TreeMap<>();

    /**
     * TreeMap to store course information with course code as key.
     */
    private TreeMap<String, Course> course = new TreeMap<>();

    /**
     * List of courses without sorting, used for processing exceptions.
     */
    private ArrayList<String> unsortedCourse = new ArrayList<>();

    /**
     * List of all courses that may have exceptions.
     */
    private ArrayList<String> allCourseWithExceptions = new ArrayList<>();

    /**
     * Faculty members data obtained from Person class.
     */
    TreeMap<String, FacultyMember> facultyMember = Person.getFacultyMember();

    /**
     * Students data obtained from Person class.
     */
    TreeMap<String, Student> student = Student.getStudent();

    /**
     * Mapping of courses to students (course code to list of student IDs).
     */
    HashMap<String, ArrayList<String>> courseStudents = Person.getCourseStudents();

    /**
     * Mapping of course instructors (course code to faculty member ID).
     */
    HashMap<String, String> courseInstructor = Person.getCourseInstructor();

    /**
     * Student grades data from Person class (student ID to list of grades).
     */
    TreeMap<String, ArrayList<String>> grades = Person.getGrades();

    /**
     * Faculty assignments data from Person class.
     */
    TreeMap<String, ArrayList<String>> facultyAssignments = Person.getFacultyAssignments();

    /**
     * Student assignments data from Person class.
     */
    TreeMap<String, ArrayList<String>> studentAssignments = Person.getStudentAssignments();

    /**
     * List of students and their courses, used for grade processing.
     */
    ArrayList<ArrayList<String>> studentAndCourses = Person.getStudentAndCourses();

    /**
     * Validates all data and writes exception messages to the output file.
     * @param writer PrintWriter instance for writing output.
     */
    public void exceptions(PrintWriter writer) {
        writer.println("Reading Departments ");
        for (Department dept : department.values()) {
            try {
                if (!facultyMember.containsKey(dept.getHead())) {//give an error message if the id is not among the ids of the faculty members
                    throw new CustomException.PersonNotFoundException("Academic Member Not Found with ID " + dept.getHead());
                }
            } catch (CustomException.PersonNotFoundException e) {
                writer.println(e.getMessage());
            }
        }

        writer.println("Reading Programs ");
        writer.println("Reading Courses ");
        for (String course : allCourseWithExceptions) {
            try {
                if (!program.containsKey(course)) {//give an error message if the code is not among the codes of the courses
                    throw new CustomException.ProgramNotFoundException("Program " + course + " Not Found");
                }
            } catch (CustomException.ProgramNotFoundException e) {
                writer.println(e.getMessage());
            }
        }

        writer.println("Reading Course Assignments ");
        for (String facultyMem : facultyAssignments.keySet()) {
            try {
                if (!facultyMember.containsKey(facultyMem)) {//give an error message if the id is not among the ids of the faculty members
                    throw new CustomException.PersonNotFoundException("Academic Member Not Found with ID " + facultyMem);
                } else {
                    for (String courses : facultyAssignments.get(facultyMem)) {
                        if (!course.containsKey(courses)) {//give an error message if the code is not among the codes of the courses
                            throw new CustomException.CourseNotFoundException("Course " + courses + " Not Found");
                        }
                    }
                }
            } catch (CustomException.PersonNotFoundException | CustomException.CourseNotFoundException e) {
                writer.println(e.getMessage());
            }
        }

        for (String students : studentAssignments.keySet()) {
            try {
                if (!student.containsKey(students)) {//give an error message if the id is not among the ids of the students
                    throw new CustomException.PersonNotFoundException("Student Not Found with ID " + students);
                } else {
                    for (String courses : studentAssignments.get(students)) {
                        if (!course.containsKey(courses)) {//give an error message if the code is not among the codes of the courses
                            throw new CustomException.CourseNotFoundException("Course " + courses + " Not Found");
                        }
                    }
                }
            } catch (CustomException.PersonNotFoundException | CustomException.CourseNotFoundException e) {
                writer.println(e.getMessage());
            }
        }

        writer.println("Reading Grades ");
        for (ArrayList<String> students : studentAndCourses) {
            try {
                if (!student.containsKey(students.get(0))) {//give an error message if the id is not among the ids of the students
                    throw new CustomException.PersonNotFoundException("Student Not Found with ID " + students.get(0));
                } else if (!course.containsKey(students.get(1))) {//give an error message if the code is not among the codes of the courses
                    throw new CustomException.CourseNotFoundException("Course " + students.get(1) + " Not Found");
                }
            } catch (CustomException.PersonNotFoundException | CustomException.CourseNotFoundException e) {
                writer.println(e.getMessage());
            }
        }
    }
    /**
     * Reads department data from a file and stores it in the department map.
     * @param input File path of the department data.
     */
    public void departmentTxt(String input) {
        try (
                BufferedReader br = new BufferedReader(new FileReader(
                        input))) {
            String line;

            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;
                String[] parts = line.split(",");
                String code = parts[0];
                String name = parts[1];
                String description= parts[2];
                String head = parts[3];
                department.put(code,new Department(code,name,description,head));}
        } catch (IOException e) {
            e.printStackTrace();}
    }/**
     * Reads course data from a file and stores it in the course map.
     * @param input File path of the course data.
     */
    public void courseTxt(String input) {
        try (
                BufferedReader br = new BufferedReader(new FileReader(
                        input))) {
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;
                String[] parts = line.split(",");
                String code = parts[0];
                String name = parts[1];
                String department = parts[2];
                int credits = Integer.parseInt(parts[3]);
                String semester = parts[4];
                String programCode = parts[5];
                allCourseWithExceptions.add(programCode);
                if (programCode.equalsIgnoreCase("BBM") || programCode.equalsIgnoreCase("AIN")){
                unsortedCourse.add(code);
                course.put(code,new Course(code,name,department,credits,semester,programCode));}
            }
        } catch (IOException e) {
            e.printStackTrace();}
    } /**
     * Reads program data from a file and stores it in the program map.
     * @param input File path of the program data.
     */
    public void programTxt(String input) {
        try (
                BufferedReader br = new BufferedReader(new FileReader(
                        input))) {
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;
                String[] parts = line.split(",");
                String code = parts[0];
                String name = parts[1];
                String description = parts[2];
                String department = parts[3];
                String degreeLevel = parts[4];
                int totalCredits = Integer.parseInt(parts[5]);
                program.put(code, new Program(code, name, description, department, degreeLevel, totalCredits));

            }
        } catch (IOException e) {
            e.printStackTrace();}
    }/**
     * Generates a detailed report of all courses and writes it to the output file.
     * @param writer PrintWriter instance for writing output.
     */
    public void coursesInfo(PrintWriter writer){
        writer.println("\n---------------------------------------\n" +
                "                COURSES\n" +
                "---------------------------------------");
        for (Course course1 :course.values()){
            writer.println("Course Code: " + course1.getCode() + "\nName: " + course1.getName() + "\nDepartment: " + course1.getDepartment() + "\nCredits: " + course1.getCredits() + "\nSemester: " + course1.getSemester() + "\n");

        }
        writer.println("----------------------------------------");
    } /**
     * Generates a detailed report of all programs and writes it to the output file.
     * @param writer PrintWriter instance for writing output.
     */
    public void programInfo(PrintWriter writer){
        writer.println("\n--------------------------------------\n" +
                "                PROGRAMS\n" +
                "---------------------------------------");
        ArrayList<String> ainCourses = new ArrayList<>();
        ArrayList<String> bbmCourses = new ArrayList<>();
        for (String courseCode : unsortedCourse) {
            if (courseCode.startsWith("BBM")) {
                bbmCourses.add(courseCode);
            } else if (courseCode.startsWith("AIN")) {
                ainCourses.add(courseCode);}
        }
        String ainFormatted = "{" + String.join(",", ainCourses) + "}";
        String bbmFormatted = "{" + String.join(",", bbmCourses) + "}";
        if (ainCourses.isEmpty()){
            ainFormatted = "- ";
        }
        if (bbmCourses.isEmpty()){
            bbmFormatted = "- ";
        }
        int number =0;
        for (String program1 : program.keySet()) {
            number++;
            writer.println("Program Code: " + program1 + "\nName: " + program.get(program1).getName() + "\nDepartment: " + program.get(program1).getDepartment() + "\nDegree Level: " + program.get(program1).getDegreeLevel() + "\nRequired Credits: " + program.get(program1).getTotalCredits() + "\nCourses: " + (program1.startsWith("BBM") ? bbmFormatted : ainFormatted));
            if (number!=program.size() || !bbmFormatted.equalsIgnoreCase("- ")){writer.println();}
        }writer.println("----------------------------------------");
    }/**
     * Generates a detailed report of all departments and writes it to the output file.
     * @param writer PrintWriter instance for writing output.
     */
    public void departmentInfo(PrintWriter writer){
        writer.println("\n---------------------------------------\n" +
                "              DEPARTMENTS\n" +
                "---------------------------------------");
        for (Department department1 : department.values()){
            try {
                if (facultyMember.get(department1.getHead())==null) {//give an error message if the id is not among the ids of the faculty members
                    throw new CustomException.PersonNotFoundException("Department Code: " + department1.getCode() + "\nName: " + department1.getName() + "\nHead: Not assigned\n");
        }else
            writer.println("Department Code: " + department1.getCode() +"\nName: " + department1.getName()+ "\nHead: " + facultyMember.get(department1.getHead()).getName() +"\n");}
            catch (CustomException.PersonNotFoundException e){
                writer.println(e.getMessage());
            }
        }

        writer.println("----------------------------------------");
    }/**
     * Converts letter grades to GPA values.
     * @param letterGrade Letter grade as a string (A1, B2, etc.).
     * @return GPA value corresponding to the letter grade.
     */
    public double convertLetterGradeToGPA(String letterGrade){
        switch (letterGrade){
            case "A1" : return 4.00;
            case "A2": return 3.50;
            case "B1": return 3.00;
            case "B2": return 2.50;
            case "C1": return 2.00;
            case "C2": return 1.50;
            case "D1": return 1.00;
            case "D2": return 0.50;
            case "F3": return 0.00;
            default: return -1.00;
        }
    }/**
     * Calculates the GPA of a student based on their grades.
     * @param list List of courses and their respective grades.
     * @return Formatted GPA value as a string.
     */
    public String calcGrade(ArrayList<ArrayList<String>> list){
        DecimalFormatSymbols symbols = new DecimalFormatSymbols(Locale.US);
        DecimalFormat df = new DecimalFormat("0.00", symbols);
        double grade = 0;
        int totalCredit=0;
        if (list!=null){
        for (ArrayList<String> list1:list){
            if(course.get(list1.get(0))!=null && convertLetterGradeToGPA(list1.get(1))>=0){
            grade+=(course.get(list1.get(0)).getCredits()) * (convertLetterGradeToGPA(list1.get(1)));
            totalCredit+=course.get(list1.get(0)).getCredits();}}
        }
        double gpa = grade / totalCredit;
        if (gpa>=0.0){
        return df.format(gpa);}
        return "0.00";
    }/**
     * Generates a detailed report of all courses with their statistics and writes it to the output file.
     * @param writer PrintWriter instance for writing output.
     */
    public void courseReports(PrintWriter writer){
        DecimalFormatSymbols symbols = new DecimalFormatSymbols(Locale.US);
        DecimalFormat df = new DecimalFormat("0.00", symbols);

        writer.println("\n----------------------------------------\n" +
                "             COURSE REPORTS\n" +
                "----------------------------------------");
        int number =0;
        for (Course course1 : course.values()){
            number++;
            double totalGrade =0.0;
            int totalPerson =0;
            TreeMap<String,Integer> grade = new TreeMap<>();
            writer.println("Course Code: " + course1.getCode() + "\nName: " + course1.getName() + "\nDepartment: " + course1.getDepartment()
                    + "\nCredits: " + course1.getCredits() + "\nSemester: " +course1.getSemester() +"\n");
            try{
            if (courseInstructor.get(course1.getCode())!=null){//give an error message if the id is not among the ids of the faculty members
            writer.println("Instructor: " + facultyMember.get(courseInstructor.get(course1.getCode())).getName() + "\n");}
            else throw new CustomException.PersonNotFoundException("Instructor: Not assigned\n");}
            catch (CustomException.PersonNotFoundException e){
                writer.println(e.getMessage());
            }
            writer.println("Enrolled Students:");

            if (courseStudents.get(course1.getCode())!=null){//give an error message if the id is not among the ids of the students
            for (String students : courseStudents.get(course1.getCode())){
                writer.println("- " + student.get(students).getName() + " (ID: " + student.get(students).getId() +")");
            }}
            writer.println("\nGrade Distribution:");
            if (grades.get(course1.getCode())!=null){//give an error message if the code is not among the codes of the courses
                for (String g : grades.get(course1.getCode())) {
                    grade.putIfAbsent(g,0);}
                for (String g : grade.keySet()){
                    int count =0;
                    for (String g1 : grades.get(course1.getCode())) {
                        if (g.equalsIgnoreCase(g1)){count++;}}
                    grade.put(g,count);
                }
                for(String grade1 : grade.keySet()){
                    if (convertLetterGradeToGPA(grade1)>=0){
                        writer.println(grade1 +": " + grade.get(grade1));
                        totalGrade += convertLetterGradeToGPA(grade1) * grade.get(grade1);}
                    else totalGrade+=0;
                    totalPerson += grade.get(grade1);
                }
                writer.println("\nAverage Grade: " + df.format(totalGrade/totalPerson ));
            }else writer.println("\nAverage Grade: 0.00");
            if (number==course.values().size()){writer.println();}
            writer.println("\n----------------------------------------\n");
        }
    }
    /**
     * Generates a detailed report of all students with their details and writes it to the output file.
     * @param writer PrintWriter instance for writing output.
     */
    public void studentInformation(PrintWriter writer){
        writer.println("----------------------------------------\n" +
                "            STUDENT REPORTS\n" +
                "----------------------------------------");
        int number =0;
        for (Student s : student.values()){
            number++;
            writer.println(s);
            writer.println("\n\nEnrolled Courses:");
            for (String courses: s.enrolledCourses()){
                if (course.get(courses)!=null){
                writer.println("- " + course.get(courses).getName() + " (" + courses + ")");}
            }
            writer.println("\nCompleted Courses:");
            if (s.getStudentGrades().get(s.getId())!=null){
            for (ArrayList<String> courses : s.getStudentGrades().get(s.getId())){
                if (course.get(courses.get(0))!=null && convertLetterGradeToGPA(courses.get(1))>=0){
                writer.println("- " + course.get(courses.get(0)).getName() + " (" + courses.get(0) + "): " + courses.get(1));
            }}}
            writer.println("\nGPA: " + calcGrade(s.getStudentGrades().get(s.getId())));
            if (number==student.size()){
                writer.println();
                writer.print("----------------------------------------");
            }else
                writer.println("----------------------------------------\n");
        }
    }

}
