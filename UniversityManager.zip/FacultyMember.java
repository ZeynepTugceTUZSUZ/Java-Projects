import java.util.HashMap;
/**
 * Represents a faculty member within the university.
 * Inherits from the Person class and maintains course assignments.
 */
public class FacultyMember extends Person{
    /**
     * HashMap storing course assignments for the faculty member.
     * Key is the faculty member's ID, value is the course code.
     */
    private HashMap<String, String> assignments = new HashMap<>();

    /**
     * Constructs a FacultyMember object with the given details.
     *
     * @param id the unique identifier of the faculty member
     * @param name the name of the faculty member
     * @param email the email address of the faculty member
     * @param department the department of the faculty member
     */
    FacultyMember(String id, String name, String email, String department) {
        super(id, name, email, department);
    }
    /**
     * Assigns a course to this faculty member.
     *
     * @param courseCode the code of the course to be assigned
     */
    @Override
    public void assignment(String courseCode) {
        assignments.put(getId(), courseCode);
    }
    /**
     * Retrieves the course assignments of this faculty member.
     *
     * @return a HashMap of course assignments
     */
    public HashMap<String, String> getAssignments() {
        return assignments;
    }
    /**
     * Returns a string representation of the faculty member.
     *
     * @return a formatted string containing faculty member details
     */
    @Override
    public String toString() {
        return "Faculty ID: " + getId() +"\nName: " + getName() + "\nEmail: " + getEmail() + "\nDepartment: " + getDepartment();
    }
}
