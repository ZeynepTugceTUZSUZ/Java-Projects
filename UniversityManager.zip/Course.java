/**
 * Represents a Course in an academic setting, extending the AcademicEntity class.
 * A Course is characterized by its department, credit value, semester, and associated program code.
 */
public class Course extends AcademicEntity{
    private String department;  // The department offering the course
    private int credits;        // The number of credits for the course
    private String semester;    // The semester in which the course is offered
    private String programCode; // The program code associated with this course

    /**
     * Constructs a Course object with specified attributes.
     *
     * @param code the unique code of the course
     * @param name the name of the course
     * @param department the department offering the course
     * @param credits the number of credits for the course
     * @param semester the semester in which the course is offered
     * @param programCode the program code associated with this course
     */
    Course(String code,String name,String department,int credits,String semester,String programCode) {
        super(code, name);
        this.department = department;
        this.credits = credits;
        this.semester = semester;
        this.programCode = programCode;
    }
    /**
     * Returns the program code associated with this course.
     *
     * @return the program code
     */
    public String getProgramCode() {
        return programCode;
    }
    /**
     * Returns the semester in which the course is offered.
     *
     * @return the semester
     */
    public String getSemester() {
        return semester;
    }
    /**
     * Returns the number of credits for the course.
     *
     * @return the number of credits
     */
    public int getCredits() {
        return credits;
    }
    /**
     * Returns the department offering the course.
     *
     * @return the department
     */
    public String getDepartment() {
        return department;
    }
}