/**
 * The Main class serves as the entry point for the Student Management System.
 * It reads data from multiple input files, processes the information, and generates reports.
 *
 * <p>The input files are expected to be provided in the following order as command-line arguments:</p>
 * <ol>
 * <li>Person file (students and faculty information)</li>
 * <li>Department file</li>
 * <li>Program file</li>
 * <li>Course file</li>
 * <li>Assignment file</li>
 * <li>Grade file</li>
 * <li>Output file (where the results will be written)</li>
 * </ol>
 *
 * <p>The program loads and processes the data using the StudentManagementSystem class and generates structured
 * reports for academic members, students, departments, programs, courses, and individual student information.</p>
 */
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class Main {

    /**
     * The main method serves as the starting point of the program.
     *
     * @param args Command-line arguments containing file paths for input and output.
     */
    public static void main(String[] args) {
        String personFile = args[0];
        String departmentFile = args[1];
        String programFile = args[2];
        String courseFile = args[3];
        String assignmentFile = args[4];
        String gradeFile = args[5];
        String outputFile = args[6];

        try (PrintWriter writer = new PrintWriter(new FileWriter(outputFile))) {

        Person personLoader = new Student("","","","");
        StudentManagementSystem sms = new StudentManagementSystem();
        personLoader.personTxt(personFile,writer);
        sms.departmentTxt(departmentFile);
        sms.courseTxt(courseFile);
        sms.programTxt(programFile);
        personLoader.assignmentTxt(assignmentFile);
        personLoader.gradeTxt(gradeFile);
        sms.exceptions(writer);
        personLoader.AcademicMemberInfo(writer);
        personLoader.studentInfo(writer);
        sms.departmentInfo(writer);
        sms.programInfo(writer);
        sms.coursesInfo(writer);
        sms.courseReports(writer);
        sms.studentInformation(writer);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}//java Main persons.txt departments.txt programs.txt courses.txt assignments.txt grades.txt output.txt