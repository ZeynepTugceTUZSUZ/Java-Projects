/**
 * Represents a Department, which is a type of AcademicEntity.
 * Each department has a code, name, description, and a department head.
 */
public class Department extends AcademicEntity{
    /**
     * Description of the department.
     */
    private String description;
    /**
     * Head of the department.
     */
    private String head;
    /**
     * Constructs a new Department object with the specified code, name, description, and head.
     *
     * @param code The code of the department.
     * @param name The name of the department.
     * @param description The description of the department.
     * @param head The head of the department.
     */
    Department(String code, String name, String description, String head) {
        super(code, name);
        this.description = description;
        this.head = head;
    }
    /**
     * Returns the head of the department.
     *
     * @return The head of the department.
     */
    public String getHead() {
        return head;
    }
    /**
     * Returns the description of the department.
     *
     * @return The description of the department.
     */
    public String getDescription() {
        return description;
    }
}