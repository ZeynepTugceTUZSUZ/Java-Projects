/**
 * Represents an abstract academic entity with a code and name.
 * This class serves as a base for other academic entities such as courses or departments.
 */
public abstract class AcademicEntity {
    /**
     * The unique code of the academic entity.
     */
    private String code;
    /**
     * The name of the academic entity.
     */
    private String name;

    /**
     * Constructs an AcademicEntity with a specified code and name.
     *
     * @param code The unique code of the academic entity.
     * @param name The name of the academic entity.
     */
    AcademicEntity(String code, String name) {
        this.code = code;
        this.name = name;
    }
    /**
     * Retrieves the name of the academic entity.
     *
     * @return The name of the academic entity.
     */
    public String getName() {
        return name;
    }
    /**
     * Retrieves the unique code of the academic entity.
     *
     * @return The code of the academic entity.
     */
    public String getCode() {
        return code;
    }
}
