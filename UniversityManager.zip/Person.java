import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.TreeMap;
/**
 * Abstract class representing a Person in the system (either Student or FacultyMember).
 * Implements the Interface class.
 */
public abstract class Person implements Interface{
    private String id; // Unique identifier for the person
    private String name; // Name of the person
    private String email; // Email of the person
    private String department; // Department of the person

    // Static collections for storing student, faculty, and assignment data
    private static TreeMap<String, Student> student = new TreeMap<>();
    private static TreeMap<String, FacultyMember> facultyMember = new TreeMap<>();
    private static HashMap<String, String> courseInstructor = new HashMap<>();
    private static HashMap<String, ArrayList<String>> courseStudents = new HashMap<>();
    private static TreeMap<String, ArrayList<String>> grades = new TreeMap<>();
    private static TreeMap<String, ArrayList<String>> facultyAssignments = new TreeMap<>();
    private static TreeMap<String, ArrayList<String>> studentAssignments = new TreeMap<>();
    private static ArrayList<ArrayList<String>> studentAndCourses = new ArrayList<>();

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getDepartment() {
        return department;
    }
    /**
     * Constructor for the Person class.
     * @param id The unique identifier for the person.
     * @param name The name of the person.
     * @param email The email of the person.
     * @param department The department of the person.
     */
    Person(String id, String name, String email, String department){
        this.id=id;
        this.name=name;
        this.email=email;
        this.department=department;
    }
    /**
     * Reads person data (Student or FacultyMember) from a file and adds them to the respective collections.
     * @param input The file path of the input file.
     * @param writer The PrintWriter for logging exceptions.
     */
    public void personTxt(String input, PrintWriter writer) {
        try (
                BufferedReader br = new BufferedReader(new FileReader(
                        input))) {
            String line;
            writer.println("Reading Person Information ");
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;
                String[] parts = line.split(",");
                String classType = parts[0];
                id = parts[1];
                name = parts[2];
                email = parts[3];
                department = parts[4];
                try {
                if (classType.equalsIgnoreCase("S")){
                    student.put(id,new Student(id,name,email,department));

                } else if (classType.equalsIgnoreCase("F")) {
                    facultyMember.put(id,new FacultyMember(id,name,email,department));
                }else throw new CustomException.InvalidPersonType("Invalid Person Type");}//give an error messages if the classType is invalid
                catch (CustomException.InvalidPersonType e){
                    writer.println(e.getMessage());
                }

            }
        } catch (IOException e) {
            e.printStackTrace();}
    }
    /**
     * Retrieves the map of faculty members.
     *
     * @return TreeMap containing faculty members with their IDs.
     */
    public static TreeMap<String, FacultyMember> getFacultyMember() {
        return facultyMember;
    }

    /**
     * Retrieves the map of students.
     *
     * @return TreeMap containing students with their IDs.
     */
    public static TreeMap<String, Student> getStudent() {
        return student;
    }

    /**
     * Retrieves the map of course students.
     *
     * @return HashMap containing lists of students for each course.
     */
    public static HashMap<String, ArrayList<String>> getCourseStudents() {
        return courseStudents;
    }

    /**
     * Retrieves the map of course instructors.
     *
     * @return HashMap mapping course codes to instructor IDs.
     */
    public static HashMap<String, String> getCourseInstructor() {
        return courseInstructor;
    }

    /**
     * Retrieves the map of course grades.
     *
     * @return TreeMap containing lists of grades for each course.
     */
    public static TreeMap<String, ArrayList<String>> getGrades() {
        return grades;
    }

    /**
     * Retrieves the map of student assignments.
     *
     * @return TreeMap containing lists of assigned courses for each student.
     */
    public static TreeMap<String, ArrayList<String>> getStudentAssignments() {
        return studentAssignments;
    }

    /**
     * Retrieves the map of faculty assignments.
     *
     * @return TreeMap containing lists of assigned courses for each faculty member.
     */
    public static TreeMap<String, ArrayList<String>> getFacultyAssignments() {
        return facultyAssignments;
    }

    /**
     * Retrieves the list of student and course pairs for grade management.
     *
     * @return ArrayList containing lists of student-course pairs.
     */
    public static ArrayList<ArrayList<String>> getStudentAndCourses() {
        return studentAndCourses;
    }

    /**
     * Prints information about academic members (faculty).
     *
     * @param writer PrintWriter to write the information.
     */
    public void AcademicMemberInfo(PrintWriter writer){
        writer.println("----------------------------------------\n" +
                "            Academic Members\n" +
                "----------------------------------------");
        for (FacultyMember facultyMember1 : getFacultyMember().values()){
            writer.println(facultyMember1);
            writer.println();}
        writer.println("----------------------------------------");
    }
    /**
     * Prints information about students.
     *
     * @param writer PrintWriter to write the information.
     */
    public void studentInfo(PrintWriter writer){
        writer.println("\n----------------------------------------\n" +
                "                STUDENTS\n" +
                "----------------------------------------");
        for (Student student1 : getStudent().values()){
            writer.println(student1);
            writer.println();}
        writer.println("----------------------------------------");
    }
    /**
     * Reads assignment data from a file and assigns courses to students and faculty.
     *
     * @param input Path of the assignment file.
     */
    public void assignmentTxt(String input) {
        try (
                BufferedReader br = new BufferedReader(new FileReader(
                        input))) {
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;
                String[] parts = line.split(",");
                String classType = parts[0];
                id = parts[1];
                String courseCode = parts[2];
                if (classType.equalsIgnoreCase("S")) {
                    studentAssignments.putIfAbsent(id,new ArrayList<>());
                    studentAssignments.get(id).add(courseCode);
                    Student s = getStudent().get(id);
                    if (s != null) {
                        s.assignment(courseCode);
                        courseStudents.putIfAbsent(courseCode,new ArrayList<>());
                        courseStudents.get(courseCode).add(id);
                    }
                }
                else if (classType.equalsIgnoreCase("F")) {
                    facultyAssignments.putIfAbsent(id,new ArrayList<>());
                    facultyAssignments.get(id).add(courseCode);
                    FacultyMember f = getFacultyMember().get(id);
                    if (f != null) {
                        f.assignment(courseCode);
                        courseInstructor.put(courseCode,id);
                    }
                }

            }
        } catch (IOException e) {
            e.printStackTrace();}
    }
    /**
     * Reads grade data from a file and assigns grades to students.
     *
     * @param input Path of the grade file.
     */
    public void gradeTxt(String input) {
        try (
                BufferedReader br = new BufferedReader(new FileReader(
                        input))) {
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;
                String[] parts = line.split(",");
                String letterGrade = parts[0];
                String studentID = parts[1];
                String courseCode = parts[2];
                Student s = getStudent().get(studentID);
                ArrayList<String> tempList = new ArrayList<>();
                tempList.add(studentID);
                tempList.add(courseCode);
                studentAndCourses.add(tempList);
                if (s != null) {
                    s.studentGrade(letterGrade, courseCode);
                    grades.putIfAbsent(courseCode,new ArrayList<>());
                    grades.get(courseCode).add(letterGrade);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();}
    }
    /**
     * Abstract method to assign a course to a person.
     * @param courseCode The course code to be assigned.
     */
    public abstract void assignment(String courseCode);
    /**
     * Method to record a student's grade for a course.
     * @param letterGrade The letter grade received.
     * @param courseCode The course code for which the grade is given.
     */
    public void studentGrade(String letterGrade, String courseCode){}
    /**
     * Abstract method to provide a string representation of the person.
     * @return A string representation of the person.
     */
    public abstract String toString();
}
