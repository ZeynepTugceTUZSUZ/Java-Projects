public interface Interface {
    void assignment(String courseCode);
    String toString();
}
