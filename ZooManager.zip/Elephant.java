import java.io.PrintWriter;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;
/**
 * Represents an Elephant in the zoo. Inherits from the abstract Animal class.
 * Provides functionality for calculating meal size, feeding, and habitat cleaning.
 */
public class Elephant extends Animal{
    /** Default meal size for an elephant aged 20. */
    private static final double default_Meal_Size = 10.0;
    /** Additional meal size per year difference from age 20. */
    private static final double age_Meal_Diff = 0.015;
    /**
     * Constructs an Elephant with the specified name and age.
     * @param name the name of the elephant.
     * @param age the age of the elephant.
     */
    Elephant(String name, int age) {
        super(name, age);
    }
    /**
     * Calculates the required meal size for the elephant based on its age.
     * @return the calculated meal size in kilograms.
     */
    public double calcMealSize(){
        int ageDiff= (getAge() - 20);
        double mealSize = default_Meal_Size + (ageDiff * age_Meal_Diff);
        return mealSize;
    }
    /**
     * Feeds the elephant with the specified number of meals.
     * If there is not enough plant-based food in stock, an error message is printed.
     * @param numberOfMeals the number of meals to be given.
     */
    @Override
    public void feed(int numberOfMeals,PrintWriter writer) {
        DecimalFormatSymbols symbols = new DecimalFormatSymbols(Locale.US);
        DecimalFormat df = new DecimalFormat("0.000", symbols);
        Double mealSize = numberOfMeals*calcMealSize();
        try {
            if (getFood().get("Plant") < mealSize){
                throw new ZooException.InsufficientFoodException("Error: Not enough Plant");
        }
        getFood().put("Plant",(getFood().get("Plant")-mealSize));
            writer.println(getName() + " has been given " + df.format(mealSize) +" kgs assorted fruits and hay");
        } catch (ZooException.InsufficientFoodException e) {
            writer.println(e.getMessage());
        }

    }
    /**
     * Provides the habitat cleaning procedure specific to elephants.
     * @return a string describing the cleaning steps.
     */
    @Override
    public String cleanHabitat() {
        return " Washing the water area.";
    }
}
