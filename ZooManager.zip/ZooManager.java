import java.io.*;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
/**
 * The ZooManager class manages all interactions within the zoo simulation,
 * including processing commands such as listing food stock, animal visitations, and feeding animals.
 */
public class ZooManager {
    private String command;
    private String personId;
    private String animalName;
    private int numberOfMeals;

    private HashMap<String, Animal> animals;
    private Map<String, People> people;
    private Map<String,Double> food;
    /**
     * Constructs a ZooManager with given animals, people, and food stock maps.
     * @param animal a map of animal names to Animal objects.
     * @param people a map of person IDs to People objects.
     * @param food a map of food types to their available quantities in kilograms.
     */
    public ZooManager(HashMap<String, Animal> animal, Map<String, People> people,Map<String,Double> food) {
        this.animals = animal;
        this.people = people;
        this.food=food;
    }
    /**
     * Reads and processes commands from a given input text file.
     * Each command is executed according to its type.
     * @param input the file path to the command file.
     */
    public void commandTxt(String input,PrintWriter writer) {
        try (BufferedReader br = new BufferedReader(new FileReader(
                input))) {
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;
                String[] parts = line.split(",");
                command = parts[0];
                switch (command) {
                    case "List Food Stock":
                        listFoodStock(writer);
                        break;
                    case "Animal Visitation":
                        animalVisitation(parts,writer);
                        break;
                    case "Feed Animal":
                        feedAnimal(parts,writer);
                        break;
                    default:
                        writer.println("Invalid command: " + command);
                        break;}
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    /**
     * Prints the current available stock of each food type.
     */
    public void listFoodStock(PrintWriter writer){
        DecimalFormatSymbols symbols = new DecimalFormatSymbols(Locale.US);
        DecimalFormat df = new DecimalFormat("0.000", symbols);
        writer.println("***********************************\n" +
                "***Processing new Command***\n" +
                "Listing available Food Stock:");
            writer.println("Plant: " + df.format(food.get("Plant")) +" kgs");
            writer.println("Fish: " + df.format(food.get("Fish")) +" kgs");
            writer.println("Meat: " + df.format(food.get("Meat")) +" kgs");
    }
    /**
     * Processes an animal visitation command.
     * Allows a person to visit an animal if both exist in the system.
     * Prints an error message if either the person or animal is not found.
     * @param parts the command line split into parts (includes person ID and animal name).
     */
    public void animalVisitation(String[] parts,PrintWriter writer){
        personId = parts[1];
        animalName = parts[2];
        try {
            People person = people.get(personId);
            if (person == null) {
                writer.println("***********************************\n" +
                        "***Processing new Command***");
                throw new ZooException.PersonNotFoundException("Error: There are no visitors or personnel with the id " + personId +".");
            }
            Animal animal = animals.get(animalName);
            if (animal == null) {
                writer.println("***********************************\n" +
                        "***Processing new Command***");
                writer.println(person.getName() + " attempts to clean " + animalName +"'s habitat.");
                throw new ZooException.AnimalNotFoundException("Error: There are no animals with the name " + animalName + ".");
            }
        person.visitAnimal(animal,writer);
        }catch (ZooException.PersonNotFoundException | ZooException.AnimalNotFoundException e) {
            writer.println(e.getMessage());
        }
    }
    /**
     * Processes a feed animal command.
     * Retrieves the person and animal and attempts to feed the animal.
     * @param parts the command line split into parts (includes person ID, animal name, and number of meals).
     */
    public void feedAnimal(String[] parts,PrintWriter writer) {
            personId = parts[1];
            animalName = parts[2];
            try {
                numberOfMeals = Integer.parseInt(parts[3]);
                People person = people.get(personId);
                if (person == null) {
                    writer.println("***********************************\n" +
                            "***Processing new Command***");
                    throw new ZooException.PersonNotFoundException("Error: There are no visitors or personnel with the id " + personId);
                }
                Animal animal = animals.get(animalName);
                if (animal == null) {
                    writer.println("***********************************\n" +
                            "***Processing new Command***");
                    writer.println(person.getName() + " attempts to feed " + animalName + ".");
                    throw new ZooException.AnimalNotFoundException("Error: There are no animals with the name " + animalName + ".");
                }
                person.feedAnimal(animal, numberOfMeals,writer);
            } catch (NumberFormatException e) {
                writer.println("***********************************\n" +
                        "***Processing new Command***");
                writer.println("Error processing command: " + command + "," + personId + "," + animalName + "," + parts[3]);
                writer.println("Error:For input string: " + '"' + parts[3] + '"');
            } catch (ZooException.PersonNotFoundException | ZooException.AnimalNotFoundException e) {
                writer.println(e.getMessage());
            }
    }

}
