public class ZooException {

    public static class PersonNotFoundException extends RuntimeException {
        public PersonNotFoundException(String message) {
            super(message);
        }
    }

    public static class AnimalNotFoundException extends RuntimeException {
        public AnimalNotFoundException(String message) {
            super(message);
        }
    }

    public static class InsufficientFoodException extends RuntimeException {
        public InsufficientFoodException(String message) {
            super(message);
        }
    }
}


