import java.io.*;
import java.util.HashMap;
/**
 * The abstract class People represents a person in the zoo system.
 * It can either be a Visitor or a Personnel.
 * Stores common attributes and functionalities shared by all people types.
 */
public abstract class People {
    private String name;
    private String id;
    /**
     * A static HashMap that keeps track of all registered people using their ID as a key.
     */
    private static HashMap<String, People> people = new HashMap<>();

    /**
     * Constructs a People object with the specified name and ID.
     * @param name the name of the person.
     * @param id the ID of the person.
     */
    public People(String name,String id){
        this.name=name;
        this.id=id;
    }
    /**
     * Gets the name of the person.
     * @return the name of the person.
     */
    public String getName() {
        return name;
    }
    /**
     * Reads people information from a given file, creates appropriate Visitor or Personnel
     * Instances, and stores them in the static people map.
     * Prints messages to confirm successful initialization.
     * @param input the path to the people input file.
     */
    public void peopleTxt(String input,PrintWriter writer) {
        try (
                BufferedReader br = new BufferedReader(new FileReader(
                        input))) {
            String line;
            writer.println("***********************************\n" +
                    "***Initializing Visitor and Personnel information***");
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;
                String[] parts = line.split(",");
                String type = parts[0];
                name = parts[1];
                id = parts[2];
                if (type.equalsIgnoreCase("Visitor")){
                    people.put(id,new Visitor(name,id));}
                else if (type.equalsIgnoreCase("Personnel")){
                    people.put(id,new Personnel(name,id));}
                else writer.println("Person is not a visitor or a personnel!");

                writer.println("Added new " + type + " with id " + id + " and name " + name + ".");
                }
        } catch (IOException e) {
            e.printStackTrace();}
        }
    /**
     * Returns the map containing all people.
     * @return the people map.
     */
    public static HashMap<String, People> getPeople() {
        return people;
    }
    /**
     * Called when a person attempts to feed an animal.
     * By default, only Personnel are allowed to feed animals.
     * Visitors receive an error message.
     * @param animal the animal to be fed.
     * @param numberOfMeals the number of meals attempted.
     */
    public void feedAnimal(Animal animal, int numberOfMeals,PrintWriter writer) {
            writer.println("***********************************\n" +
                    "***Processing new Command***");
            writer.println(getName() + " tried to feed " + animal.getName());
            writer.println("Error: Visitors do not have the authority to feed animals.");

    }
    /**
     * Abstract method that must be implemented by subclasses.
     * Defines how a person visits an animal.
     * @param animal the animal to be visited.
     */
    public abstract void visitAnimal(Animal animal,PrintWriter writer);
    }
