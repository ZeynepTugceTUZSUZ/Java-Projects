import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;
/**
 * Represents a Lion in the zoo. Inherits from the abstract Animal class.
 * Handles meal size calculation, feeding behavior, and habitat cleaning instructions specific to lions.
 */
public class Lion extends Animal{
    /** Default meal size for a lion aged 5. */
    private static final double default_Meal_Size = 5.0;
    /** Additional meal size per year difference from age 5. */
    private static final double age_Meal_Diff = 0.05;
    /**
     * Constructs a Lion with the specified name and age.
     * @param name the name of the lion.
     * @param age the age of the lion.
     */
    Lion(String name, int age) {
        super(name, age);
    }
    /**
     * Calculates the required meal size for the lion based on its age.
     * @return the calculated meal size in kilograms.
     */
    public double calcMealSize(){
        int ageDiff= (getAge() - 5);
        double mealSize = default_Meal_Size + (ageDiff * age_Meal_Diff);
        return mealSize;
    }
    /**
     * Feeds the lion with the specified number of meals.
     * If there is not enough meat in stock, prints an error message.
     * @param numberOfMeals the number of meals to be given.
     */
    @Override
    public void feed(int numberOfMeals,PrintWriter writer){
        DecimalFormatSymbols symbols = new DecimalFormatSymbols(Locale.US);
        DecimalFormat df = new DecimalFormat("0.000", symbols);
        Double mealSize = numberOfMeals*calcMealSize();
        try {
            if (getFood().get("Meat") < mealSize) {
                throw new ZooException.InsufficientFoodException("Error: Not enough Meat");
            }
        getFood().put("Meat",(getFood().get("Meat")-mealSize));
            writer.println(getName() + " has been given " + df.format(mealSize) + " kgs of meat");
        } catch (ZooException.InsufficientFoodException e) {
            writer.println(e.getMessage());
        }

    }
    /**
     * Provides the habitat cleaning procedure specific to lions.
     * @return a string describing the cleaning steps.
     */
    @Override
    public String cleanHabitat() {
        return " Removing bones and refreshing sand.";
    }
}
