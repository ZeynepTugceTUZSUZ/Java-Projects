import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
/**
 * The Main class is the entry point of the Zoo Management System simulation.
 * It initializes the zoo by loading animals, people, and food data from input files,
 * then processes a series of commands provided in another input file.
 *
 * Input arguments must be given in the following order:
 * <ul>
 *     <li>args[0] - Path to the animals data file</li>
 *     <li>args[1] - Path to the people data file</li>
 *     <li>args[2] - Path to the food stock data file</li>
 *     <li>args[3] - Path to the commands file</li>
 *     <li>args[4] - Path to the output file where logs/results will be written</li>
 * </ul>
 */
public class Main {
    /**
     * Main method that runs the Zoo Management simulation.
     * @param args Command-line arguments specifying input and output file paths.
     */
    public static void main(String[] args) {
        String animalFile = args[0];
        String peopleFile = args[1];
        String foodFile = args[2];
        String commandFile = args[3];
        String outputFile = args[4];
        try (PrintWriter writer = new PrintWriter(new FileWriter(outputFile))) {
            // Load animal data
            Animal animalLoader = new Lion("", 0);
            animalLoader.animalTxt(animalFile, writer);
            //Load people data
            People peopleLoader = new Visitor("", "");
            peopleLoader.peopleTxt(peopleFile, writer);
            //Load food stock
            animalLoader.foodTxt(foodFile, writer);
            // Process commands
            ZooManager zoo = new ZooManager(Animal.getAnimal(), People.getPeople(), Animal.getFood());
            zoo.commandTxt(commandFile, writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

