import java.io.PrintWriter;

/**
 * The Visitor class represents a visitor in the zoo, extending from the People class.
 * Visitors have the ability to visit animals but do not have the authority to perform actions like cleaning or feeding animals.
 */
public class Visitor extends People{
    /**
     * Constructs a new Visitor with the specified name and id.
     * @param name the name of the visitor
     * @param id   the unique id of the visitor
     */
    public Visitor(String name, String id) {
        super(name, id);
    }
    /**
     * Simulates the visitor registering and successfully visiting an animal.
     * Outputs the actions to the console.
     * @param animal the animal being visited by the visitor
     */
    public void visitAnimal(Animal animal,PrintWriter writer){
        writer.println("***********************************\n" +
                "***Processing new Command***");
            writer.println(this.getName() + " tried to register for a visit to " + animal.getName() + ".");
            writer.println(this.getName() + " successfully visited " + animal.getName() + ".");
        }
}
