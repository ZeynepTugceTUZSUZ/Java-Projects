import java.io.*;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.HashMap;
import java.util.Locale;

/**
 * An abstract class representing a generic Animal in the zoo.
 * Provides base functionality for all animal types such as reading animal info and managing food stock.
 */
public abstract class Animal {
    private String name;
    private int age;
    /** Static map storing all animals by their names. */
    private static HashMap<String, Animal> animal = new HashMap<>();

    /** Static map storing food stock by food type. */
    private static HashMap<String, Double> food = new HashMap<>();
    /**
     * Constructs a new Animal with the specified name and age.
     * @param name the name of the animal
     * @param age  the age of the animal
     */
    Animal(String name,int age){
        this.name=name;
        this.age=age;
    }
    /**
     * Gets the name of the animal.
     * @return the animal's name
     */
    public String getName() {
        return name;
    }
    /**
     * Gets the age of the animal.
     * @return the animal's age
     */
    public int getAge() {
        return age;
    }
    /**
     * Reads animal information from a file and creates appropriate animal objects
     * (Lion, Elephant, Penguin, Chimpanzee) based on the data.
     * @param input the file path to read animal information from
     */
    public void animalTxt(String input,PrintWriter writer) {
        try (
                BufferedReader br = new BufferedReader(new FileReader(
                        input))) {
            String line;
            writer.println("***********************************\n" +
                    "***Initializing Animal information***");
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;
                String[] parts = line.split(",");
                String type = parts[0];
                name = parts[1];
                age = Integer.parseInt(parts[2]);
                if (type.equalsIgnoreCase("Lion")){
                    animal.put(name,new Lion(name,age));}
                else if (type.equalsIgnoreCase("Elephant")){
                    animal.put(name,new Elephant(name,age));}
                else if (type.equalsIgnoreCase("Penguin")){
                    animal.put(name,new Penguin(name,age));}
                else if (type.equalsIgnoreCase("Chimpanzee")){
                    animal.put(name,new Chimpanzee(name,age));}
                else writer.println("Animal type is invalid!");
                writer.println("Added new " + type + " with name " + name + " aged " + age + ".");
            }
        } catch (IOException e) {
            e.printStackTrace();}
    }
    /**
     * Reads food stock information from a file and stores the quantities in the static food map.
     * @param input the file path to read food stock data from
     */
    public void foodTxt(String input,PrintWriter writer){
        try (
                BufferedReader br = new BufferedReader(new FileReader(
                input))) {
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;
                String[] parts = line.split(",");
                String type = parts[0];
                double quantity = Integer.parseInt(parts[1]);
                food.put(type,quantity);
            }
            DecimalFormatSymbols symbols = new DecimalFormatSymbols(Locale.US);
            DecimalFormat df = new DecimalFormat("0.000", symbols);
            writer.println("***********************************\n" +
                    "***Initializing Food Stock***");
            writer.println("There are " + df.format(food.get("Meat")) + " kg of Meat in stock");
            writer.println("There are " + df.format(food.get("Fish")) + " kg of Fish in stock");
            writer.println("There are " + df.format(food.get("Plant")) + " kg of Plant in stock");
        } catch (IOException e) {
            e.printStackTrace();}

    }
    /**
     * Gets the current food stock map.
     * @return a map of food type to available quantity
     */
    public static HashMap<String, Double> getFood() {
        return food;
    }
    /**
     * Gets the current animal map.
     * @return a map of animal names to animal objects
     */
    public static HashMap<String, Animal> getAnimal() {
        return animal;
    }
    /**
     * Abstract method to be implemented by each animal subclass to define feeding behavior.
     * @param numberOfMeals the number of meals to feed the animal
     */
    public abstract void feed(int numberOfMeals,PrintWriter writer);
    /**
     * Abstract method to be implemented by each animal subclass to describe habitat cleaning behavior.
     * @return a string describing how the habitat is cleaned
     */
    public abstract String cleanHabitat();

}
