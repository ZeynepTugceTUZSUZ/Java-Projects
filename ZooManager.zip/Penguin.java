import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;
/**
 * Represents a Penguin in the zoo. Inherits from the abstract Animal class.
 * Handles feeding behavior and habitat cleaning specific to penguins.
 */
public class Penguin extends Animal{
    /** Default meal size for a penguin aged 4. */
    private static final double default_Meal_Size = 3.0;

    /** Additional meal size per year difference from age 4. */
    private static final double age_Meal_Diff = 0.04;

    /**
     * Constructs a Penguin with the specified name and age.
     * @param name the name of the penguin.
     * @param age  the age of the penguin.
     */
    Penguin(String name, int age) {
        super(name, age);
    }
    /**
     * Calculates the required meal size for the penguin based on its age.
     * @return the calculated meal size in kilograms.
     */
    public double calcMealSize(){
        int ageDiff= (getAge() - 4);
        double mealSize = default_Meal_Size + (ageDiff * age_Meal_Diff);
        return mealSize;
    }
    /**
     * Feeds the penguin with the specified number of meals.
     * Prints an error message if there is not enough fish in the stock.
     * @param numberOfMeals the number of meals to be given.
     */
    @Override
    public void feed(int numberOfMeals,PrintWriter writer) {
        DecimalFormatSymbols symbols = new DecimalFormatSymbols(Locale.US);
        DecimalFormat df = new DecimalFormat("0.000", symbols);
        Double mealSize = numberOfMeals * calcMealSize();
        try {
            if (getFood().get("Fish") < mealSize) {
                throw new ZooException.InsufficientFoodException("Error: Not enough Fish");
            }
            getFood().put("Fish", (getFood().get("Fish") - mealSize));
            writer.println(getName() + " has been given " + df.format(mealSize) + " kgs of various kinds of fish");
        } catch (ZooException.InsufficientFoodException e) {
            writer.println(e.getMessage());
        }
    }
    /**
     * Describes the cleaning procedure for the penguin's habitat.
     * @return a string describing the cleaning steps.
     */
    @Override
    public String cleanHabitat() {
        return " Replenishing ice and scrubbing walls.";
    }
}
