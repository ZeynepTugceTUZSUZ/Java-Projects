import java.io.PrintWriter;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;
/**
 * Represents a Chimpanzee in the zoo. Inherits from the abstract Animal class.
 * Handles feeding and habitat cleaning behavior specific to chimpanzees.
 */
public class Chimpanzee extends Animal{
    /** Default meal size for a chimpanzee aged 10. */
    private static final double default_Meal_Size = 3.0;

    /** Additional meal size per year difference from age 10. */
    private static final double age_Meal_Diff = 0.0125;
    /**
     * Constructs a Chimpanzee with the specified name and age.
     * @param name the name of the chimpanzee.
     * @param age  the age of the chimpanzee.
     */
    Chimpanzee(String name, int age) {
        super(name, age);
    }
    /**
     * Calculates the required meal size for the chimpanzee based on its age.
     * @return the calculated meal size in kilograms.
     */
    public double calcMealSize(){
        int ageDiff= (getAge() - 10);
        double mealSize = default_Meal_Size + (ageDiff * age_Meal_Diff);
        return mealSize;
    }
    /**
     * Feeds the chimpanzee with the specified number of meals.
     * Requires both meat and plant stock. If stock is insufficient, an error is printed.
     * @param numberOfMeals the number of meals to be given.
     */
    @Override
    public void feed(int numberOfMeals,PrintWriter writer) {
        DecimalFormatSymbols symbols = new DecimalFormatSymbols(Locale.US);
        DecimalFormat df = new DecimalFormat("0.000", symbols);
        Double mealSize = numberOfMeals*calcMealSize();
        try {
            if (getFood().get("Meat") < mealSize) {
                throw new ZooException.InsufficientFoodException("Error: Not enough Meat");
            }
            else if (getFood().get("Plant") < mealSize){
                throw new ZooException.InsufficientFoodException("Error: Not enough Plant");
            }
            else if (getFood().get("Meat") < mealSize && getFood().get("Plant") < mealSize) {
                throw new ZooException.InsufficientFoodException("Error: Not enough Meat and Plant");}

            getFood().put("Meat",(getFood().get("Meat")-mealSize));
        getFood().put("Plant",(getFood().get("Plant")-mealSize));
            writer.println(getName() + " has been given " + df.format(mealSize) +" kgs of meat and " + df.format(mealSize) + " kgs of leaves");
        } catch (ZooException.InsufficientFoodException e) {
            writer.println(e.getMessage());
        }
    }
    /**
     * Describes the cleaning procedure for the chimpanzee's habitat.
     * @return a string describing the cleaning steps.
     */
    @Override
    public String cleanHabitat() {
        return " Sweeping the enclosure and replacing branches.";
    }
}
