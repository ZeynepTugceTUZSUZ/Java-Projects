import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * The Personnel class represents a personnel member in the zoo, extending from the People class.
 * Personnel members have the ability to visit animals, clean their habitats, and feed them.
 */
public class Personnel extends People{
    /**
     * Constructs a new Personnel with the specified name and id.
     * @param name the name of the personnel member
     * @param id   the unique id of the personnel member
     */
    public Personnel(String name, String id) {
        super(name, id);
    }
    /**
     * Simulates the personnel member visiting an animal and cleaning its habitat.
     * Outputs the actions to the console.
     * @param animal the animal whose habitat is being cleaned
     */
    public void visitAnimal(Animal animal,PrintWriter writer){
        writer.println("***********************************\n" +
                "***Processing new Command***");
            writer.println(this.getName() + " attempts to clean " + animal.getName() +"'s habitat.");
            writer.println(this.getName() + " started cleaning " + animal.getName() + "'s habitat.");
            writer.println("Cleaning " + animal.getName() + "'s habitat:" + animal.cleanHabitat());
       }
    /**
     * Simulates the personnel member feeding an animal.
     * The number of meals to be given to the animal is specified.
     * Outputs the actions to the console.
     * @param animal the animal being fed
     * @param numberOfMeals the number of meals to be provided to the animal
     */
    public void feedAnimal(Animal animal,int numberOfMeals,PrintWriter writer){
            writer.println("***********************************\n" +
                "***Processing new Command***");
            writer.println(getName() + " attempts to feed " + animal.getName() + ".");
        animal.feed(numberOfMeals,writer);
        }
}
