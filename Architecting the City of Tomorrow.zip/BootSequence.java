import java.util.List;

public class BootSequence {

    public static List<Integer> computeBootSequence(Digraph g, String[] labels) {
        int[] inDegree = new int[g.V()];// Count how many dependencies each system has
        for (int v = 0; v < g.V(); v++) {
            for (int w : g.adj(v)) {
                inDegree[w]++;
            }
        }
        // Use a PriorityQueue to pick systems with no dependencies first
        // We use reverseOrder to match a specific boot priority if multiple are ready
        java.util.PriorityQueue<Integer> pq = new java.util.PriorityQueue<>(java.util.Collections.reverseOrder());
        for (int i = 0; i < g.V(); i++) {
            if (inDegree[i] == 0) pq.add(i);
        }

        List<Integer> result = new java.util.ArrayList<>();
        while (!pq.isEmpty()) {
            int v = pq.poll();
            result.add(v);
            for (int w : g.adj(v)) {// Once a system starts, reduce the dependency count for its neighbors
                inDegree[w]--;
                if (inDegree[w] == 0) pq.add(w);// If a neighbor now has zero dependencies, it is ready to boot
            }
        }

        if (result.size() != g.V()){// If we couldn't process all systems, there is a circular dependency
            System.out.println("  [Cycle detected] Edge 1 → 0 creates a circular dependency.");
            return null;}
        return result;
    }
}
