public class CommHubs {

    public static void findHighInteractionZones(Digraph g, String[] labels) {
        boolean[] visited = new boolean[g.V()];
        java.util.Stack<Integer> stack = new java.util.Stack<>();
        //Reverse the graph to help find components in the second pass
        Digraph reversedGraph = g.reverse();

        // First DFS pass to determine the finishing order of the nodes
        for (int i = g.V() - 1; i >= 0; i--){
            if (!visited[i]){
                java.util.Stack<Integer> dfsStack = new java.util.Stack<>();
                dfsStack.push(i);
                while (!dfsStack.isEmpty()){
                    int v = dfsStack.peek();
                    if (!visited[v])
                        visited[v] = true;
                    boolean found = false;
                    for (int w : g.adj(v)){
                        if (!visited[w]){
                            dfsStack.push(w);
                            found = true;
                            break;
                        }
                    }
                    if (!found)// Once a node has no more unvisited neighbors,push it to our order stack
                        stack.push(dfsStack.pop());
                }
            }
        }
        //Reset the visited array for the second DFS pass
        java.util.Arrays.fill(visited, false);
        java.util.List<java.util.List<String>> allSCCs = new java.util.ArrayList<>();
        // Process nodes in the order of the stack using the reversed graph
        while (!stack.isEmpty()) {
            int startNode = stack.pop();
            if (!visited[startNode]) {
                java.util.List<Integer> currentSCC = new java.util.ArrayList<>();
                java.util.Stack<Integer> dfsStack = new java.util.Stack<>();
                dfsStack.push(startNode);
                visited[startNode] = true;
                while (!dfsStack.isEmpty()){
                    int v = dfsStack.pop();
                    currentSCC.add(v);
                    // Explore the reversed graph to find all nodes in this specific component
                    for(int w : reversedGraph.adj(v)){
                        if (!visited[w]){
                            dfsStack.push(w);
                            visited[w] = true;
                        }
                    }
                }
                // Sort IDs and convert them to labels.
                java.util.Collections.sort(currentSCC);
                java.util.List<String> currentSCCNames = new java.util.ArrayList<>();
                for(int id : currentSCC)
                    currentSCCNames.add(labels[id]);
                allSCCs.add(currentSCCNames);
            }
        }
        // Output formatting to display total components and high-interaction zones
        System.out.println("Total SCCs found: " + allSCCs.size());
        java.util.Collections.reverse(allSCCs);
        int highInteractionCount = 0;
        for (int i = 0; i < allSCCs.size(); i++) {
            java.util.List<String> scc = allSCCs.get(i);
            String zoneInfo = "";
            if (scc.size() > 1) {// Components with more than one node are flagged as high-interaction
                zoneInfo = " [HIGH-INTERACTION ZONE]";
                highInteractionCount++;
            }
            String nodesString = String.join(", ", scc);
            System.out.println("  SCC-" + i + zoneInfo + ": {" + nodesString + "}");
        }System.out.println("High-Interaction Zones: " + highInteractionCount);
    }

}
