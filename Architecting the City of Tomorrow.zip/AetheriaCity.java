import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import java.io.File;

/**
 * AetheriaCity – Main entry point.
 *
 * Parse AetheriaCity.xml, build the required graphs, and call your
 * implementations in sequence.
 *
 * Usage:
 *   javac *.java -d .
 *   java AetheriaCity <AetheriaCity>
 */
public class AetheriaCity {

    public static void main(String[] args) throws Exception {
        if (args.length == 0) {
            System.err.println("Usage: java AetheriaCity <xml-file>");
            return;
        }
        Document doc = parseXML(args[0]);
        int num = doc.getElementsByTagName("district").getLength();
        String[] labels = new String[num];

        NodeList node = doc.getElementsByTagName("district");
        for(int i = 0; i < num; i++ ){
            Element district = (Element) node.item(i);
            int id = Integer.parseInt(getText(district, "id").substring(1));
            labels[id] = getText(district, "name");
        }
        System.out.println();
        System.out.println("════════════════════════════════════════════════════════════\n" +
                "  AETHERIA CITY – Full System Boot Report\n" +
                "════════════════════════════════════════════════════════════\n");

        System.out.println("════════════════════════════════════════════════════════════\n" +
                "  PART A  |  Power Grid\n" +
                "════════════════════════════════════════════════════════════");
        Graph powerGraph = new Graph(num);
        for (int i = 0; i < num; i++){
            Element district = (Element) node.item(i);
            int from = Integer.parseInt(getText(district, "id").substring(1));
            NodeList links = district.getElementsByTagName("link");
            for (int j = 0; j < links.getLength(); j++){
                Element link = (Element) links.item(j);
                int to = Integer.parseInt(getText(link, "target").substring(1));
                double weight = Double.parseDouble(getText(link, "cableCost"));
                powerGraph.addEdge(new Edge(from, to, weight));
            }
        }
        // Check connectivity and run Kruskal's algorithm
        System.out.println("City fully connected? " + (PowerGrid.isConnected(powerGraph) ? "YES " : "NO"));
        java.util.List<Edge> mst = PowerGrid.kruskalMST(powerGraph);
        System.out.println("\nMinimum Spanning Tree (" + mst.size() + " cables):");
        double totalCost = 0;
        for (Edge e : mst) {
            totalCost += e.weight();
            System.out.println("  " + String.format("%-22s", labels[e.either()]) + "  " + String.format("%-23s", labels[e.other(e.either())]) + " cost: " + (int)e.weight());
        }
        System.out.println("Total minimum cable cost: " + (int) totalCost + " units\n");

        System.out.println("════════════════════════════════════════════════════════════\n" +
                "  PART B  |  Master Boot Sequence (valid order)\n" +
                "════════════════════════════════════════════════════════════");
        System.out.println("=== Part B: Master Boot Sequence ===");

        NodeList bootNodes = doc.getElementsByTagName("s");
        int bootCount = bootNodes.getLength();
        Digraph bootDigraph = new Digraph(bootCount);
        String[] bootLabels = new String[bootCount];

        for (int i = 0; i < bootCount; i++) {
            Element sNode = (Element) bootNodes.item(i);
            int id = Integer.parseInt(getText(sNode, "id").substring(1));
            bootLabels[id] = getText(sNode, "name");
            NodeList reqs = sNode.getElementsByTagName("req");
            for (int j = 0; j < reqs.getLength(); j++) {
                String reqVal = reqs.item(j).getTextContent().trim();
                if (reqVal.length() > 1) {
                    int from = Integer.parseInt(reqVal.substring(1));
                    bootDigraph.addEdge(id,from);
                }
            }
        }

        java.util.List<Integer> bootOrder = BootSequence.computeBootSequence(bootDigraph, bootLabels);
        if (bootOrder != null) {
            System.out.println("Valid boot sequence found:");
            for (int i = 0; i < bootOrder.size(); i++) {
                int id = bootOrder.get(i);
                System.out.printf("  Step %2d: %s (id=%d)\n", (i + 1), bootLabels[id], id);
            }
        }
        else{System.out.println("SYSTEM INFEASIBLE: Circular reference (deadlock) detected!");}
        System.out.println("\n════════════════════════════════════════════════════════════\n" +
                "  PART C  |  Secure Communication Hubs (SCCs)\n" +
                "════════════════════════════════════════════════════════════");
        System.out.println("=== Part C: Secure Communication Hubs ===");
        Digraph fiberDigraph = new Digraph(num);
        NodeList stations = doc.getElementsByTagName("station");
        for (int i = 0; i < stations.getLength(); i++) {
            Element station = (Element) stations.item(i);
            int from = Integer.parseInt(getText(station, "id").substring(1));
            NodeList fiberLinks = station.getElementsByTagName("link");
            for (int j = 0; j < fiberLinks.getLength(); j++) {
                int to = Integer.parseInt(getText((Element) fiberLinks.item(j), "target").substring(1));
                fiberDigraph.addEdge(from, to);
            }
        }
        CommHubs.findHighInteractionZones(fiberDigraph, labels);

        System.out.println("\n════════════════════════════════════════════════════════════\n" +
                "  PART D  |  Bio-Leak Containment Protocol\n" +
                "════════════════════════════════════════════════════════════");
        NodeList scenarios = doc.getElementsByTagName("scenario");
        for (int i = 0; i < scenarios.getLength(); i++) {
            int srcId = Integer.parseInt(getText((Element) scenarios.item(i), "sourceId").substring(1));
            System.out.println("Leak origin: " + labels[srcId] + " (id=" + srcId + ")");

            // Task 1:DFS Reachability
            System.out.println("\n=== Part D, Task 1 " + labels[srcId] + "(" + srcId + ") ===");
            java.util.List<Integer> reachable = BioLeakContainment.dfsReachable(fiberDigraph, srcId, labels);
            System.out.println("Stations at risk (" + reachable.size() + "):");
            for (int id : reachable) System.out.println("  " + labels[id] + "(" + id + ")");

            // Task 2:BFS Evacuation Layers
            System.out.println("\n=== Part D, Task 2 " + labels[srcId] + "(" + srcId + ") ===");
            java.util.List<java.util.List<Integer>> layers = BioLeakContainment.bfsLayers(fiberDigraph, srcId, labels);
            System.out.println("Evacuation priority layers:");
            for (int d = 0; d < layers.size(); d++) {
                System.out.printf("  Layer %d %-12s: ", d, (d == 0 ? "(source)     " : "(priority " + d + ")"));
                java.util.List<Integer> nodes = layers.get(d);
                for (int j = 0; j < nodes.size(); j++) {
                    System.out.print(labels[nodes.get(j)] + "(" + nodes.get(j) + ")" + (j < nodes.size() - 1 ? ", " : ""));
                }
                System.out.println();
            }
        }
    }

    // ── XML helpers ──────────────────────────────────────────────────

    private static Document parseXML(String filename) throws Exception {
        File file = new File(filename + ".xml");
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document doc = builder.parse(file);
        doc.getDocumentElement().normalize();
        return doc;
    }

    private static String getText(Element parent, String tag) {
        NodeList nl = parent.getElementsByTagName(tag);
        if (nl.getLength() == 0) return "";
        return nl.item(0).getTextContent().trim();
    }

    static void printBanner(String title) {
        String line = "═".repeat(60);
        System.out.println("\n" + line);
        System.out.println("  " + title);
        System.out.println(line);
    }
}
