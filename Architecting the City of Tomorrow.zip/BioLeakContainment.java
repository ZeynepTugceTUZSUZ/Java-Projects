import java.util.List;

public class BioLeakContainment {

    public static List<Integer> dfsReachable(Digraph g, int source, String[] labels) {
        boolean[] visited = new boolean[g.V()];
        List<Integer> reachable = new java.util.ArrayList<>();
        java.util.Stack<Integer> stack = new java.util.Stack<>();

        // Start the search from the leak origin
        stack.push(source);
        while (!stack.isEmpty()) {
            int v = stack.pop();
            if (!visited[v]) {// Only process the node if we haven't been here before
                visited[v] = true;
                reachable.add(v);

                // Sorting neighbors to ensure we visit them in a consistent order
                java.util.List<Integer> neighbors = new java.util.ArrayList<>();
                for (int w : g.adj(v))
                    neighbors.add(w);
                java.util.Collections.sort(neighbors);

                for (int w : neighbors)// Push unvisited neighbors onto the stack for further exploration
                    if (!visited[w]) stack.push(w);
            }
        }
        return reachable;
    }

    public static List<List<Integer>> bfsLayers(Digraph g, int source, String[] labels) {
        List<List<Integer>> layers = new java.util.ArrayList<>();
        int[] distTo = new int[g.V()];
        // Use -1 to mark nodes that haven't been reached yet
        java.util.Arrays.fill(distTo, -1);
        java.util.Queue<Integer> queue = new java.util.LinkedList<>();

        queue.add(source);
        distTo[source] = 0;
        while (!queue.isEmpty()){
            int v = queue.poll();
            int currentDist = distTo[v];
            while (layers.size() < currentDist + 1)// Make sure the layers list is big enough to hold the current distance
                layers.add(new java.util.ArrayList<>());
            layers.get(currentDist).add(v);// Add the current node to its corresponding distance level
            for (int w :g.adj(v)){
                if (distTo[w] == -1){// If we find a node for the first time, record its distance and queue it
                    queue.add(w);
                    distTo[w] = currentDist + 1;
                }
            }
        }
        for (List<Integer> layer : layers)// Sorting each layer by ID
            java.util.Collections.sort(layer);
        return layers;
    }
}
