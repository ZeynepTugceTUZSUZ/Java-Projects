import java.util.ArrayList;
import java.util.List;

public class PowerGrid {

    public static boolean isConnected(Graph g) {
        // Using BFS to traverse the graph and count visited nodes
        java.util.Queue<Integer> queue = new java.util.LinkedList<>();
        if (g.V() == 0) return true;
        int startNode = -1;
        for (int i = 0; i < g.V(); i++) {
            startNode = i;
            break;
        }
        if (startNode == -1) return true;

        queue.add(startNode);
        boolean[] visited = new boolean[g.V()];
        queue.add(0);
        visited[0] = true;
        int visitedCount = 1;
        while (!queue.isEmpty()){
            int v = queue.poll();
            for (Edge e : g.adj(v)){
                int w = e.other(v);
                if (!visited[w]){
                    visited[w] = true;
                    queue.add(w);
                    visitedCount++;
                }
            }
        }// If the number of visited nodes matches total nodes, the graph is connected
        return visitedCount == g.V();
    }

    public static List<Edge> kruskalMST(Graph g) {
        // PriorityQueue sorts edges by weight automatically
        java.util.PriorityQueue<Edge> pq = new java.util.PriorityQueue<>();
        for (int v = 0; v < g.V(); v++) {
            for (Edge e : g.adj(v)) {
                if (e.other(v) > v){
                    int w = e.other(v);
                    if (v < w )// Ensure each undirected edge is added only once
                        pq.add(e);

                }
            }
        }
        List<Edge> mst = new ArrayList<>();
        int[] parent = new int[g.V()];
        int[] rank = new int[g.V()];

        for (int i = 0; i < g.V(); i++){// Initialize Union-Find structure
            parent[i] = i;
            rank[i] = 0;}

        while (!pq.isEmpty() && mst.size() < g.V()-1){// Process edges in increasing order of weight
            Edge e = pq.poll();
            int v = e.either();
            int w = e.other(v);

            // Find roots of the sets containing v and w
            int rootV = v;
            while (rootV != parent[rootV]){
                rootV = parent[rootV];
            }
            // Path compression to make the tree flatter and faster
            int tempV = v;
            while (tempV != rootV) {
                int next = parent[tempV];
                parent[tempV] = rootV;
                tempV = next;
            }

            int rootW = w;
            while (rootW != parent[rootW]){
                rootW = parent[rootW];
            }
            int tempW = w;
            while (tempW != rootW) {
                int next = parent[tempW];
                parent[tempW] = rootW;
                tempW = next;
            }
            if (rootV != rootW) {// If they are in different sets, adding this edge won't create a cycle
                mst.add(e);
                if (rank[rootV] < rank[rootW]) {// Union by rank to keep the tree balanced
                    parent[rootV] = rootW;
                } else if (rank[rootV] > rank[rootW]) {
                    parent[rootW] = rootV;
                } else {
                    parent[rootV] = rootW;
                    rank[rootW]++;
                }
            }
        }
        mst.sort((e1, e2) -> {// Sort the final MST list based on weight and then by node IDs for consistent output
            if (Double.compare(e1.weight(), e2.weight()) != 0)
                return Double.compare(e1.weight(), e2.weight());

            int v1 = Math.min(e1.either(), e1.other(e1.either()));
            int v2 = Math.min(e2.either(), e2.other(e2.either()));
            if (v1 != v2)
                return Integer.compare(v1, v2);
            int w1 = Math.max(e1.either(), e1.other(e1.either()));
            int w2 = Math.max(e2.either(), e2.other(e2.either()));
            return Integer.compare(w1, w2);
        });
        return mst;
    }
}
